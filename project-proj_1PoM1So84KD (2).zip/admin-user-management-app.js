function UserManagementPage() {
  const [userData, setUserData] = React.useState({
    totalFarmers: 124,
    totalCustomers: 856,
    activeSessions: 42,
    newRegistrations: 15,
    blockedUsers: 3,
    pendingVerifications: 8,
    dailyActiveUsers: 234,
    weeklyRetention: 78,
    monthlyGrowth: 15,
    topRegions: [
      { name: 'Punjab', percentage: 35 },
      { name: 'Maharashtra', percentage: 22 },
      { name: 'Gujarat', percentage: 18 }
    ],
    recentUsers: [
      { name: 'Riya Sen', type: 'Farmer', joined: '2025-09-22', status: 'Active' },
      { name: 'Ram Sharma', type: 'Customer', joined: '2025-09-21', status: 'Active' },
      { name: 'Priya Singh', type: 'Farmer', joined: '2025-09-20', status: 'Pending' }
    ]
  });

  const handleExportCSV = () => {
    const csvContent = `data:text/csv;charset=utf-8,Category,Value
Total Farmers,${userData.totalFarmers}
Total Customers,${userData.totalCustomers}
Active Sessions,${userData.activeSessions}
New Registrations Today,${userData.newRegistrations}
Blocked Users,${userData.blockedUsers}
Pending Verifications,${userData.pendingVerifications}
Daily Active Users,${userData.dailyActiveUsers}
Weekly Retention Rate,${userData.weeklyRetention}%
Monthly Growth,${userData.monthlyGrowth}%`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `user_management_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = () => {
    const pdfContent = `USER MANAGEMENT REPORT
Generated: ${new Date().toLocaleString()}

OVERVIEW STATISTICS:
• Total Farmers: ${userData.totalFarmers}
• Total Customers: ${userData.totalCustomers}
• Active Sessions: ${userData.activeSessions}
• New Registrations Today: ${userData.newRegistrations}
• Blocked Users: ${userData.blockedUsers}
• Pending Verifications: ${userData.pendingVerifications}

USER ACTIVITY METRICS:
• Daily Active Users: ${userData.dailyActiveUsers}
• Weekly Retention Rate: ${userData.weeklyRetention}%
• Monthly Growth: +${userData.monthlyGrowth}%

TOP REGIONS:
${userData.topRegions.map(region => `• ${region.name}: ${region.percentage}%`).join('\n')}

RECENT USER REGISTRATIONS:
${userData.recentUsers.map(user => `• ${user.name} (${user.type}) - ${user.joined} - ${user.status}`).join('\n')}

Report generated on: ${new Date().toLocaleString()}`;

    const element = document.createElement('a');
    const file = new Blob([pdfContent], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `user_management_report_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader title="User Management" />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Overview Statistics */}
        <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <div className="card text-center">
            <div className="text-2xl font-bold text-blue-600">{userData.totalFarmers}</div>
            <div className="text-sm text-gray-600">Total Farmers</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-green-600">{userData.totalCustomers}</div>
            <div className="text-sm text-gray-600">Total Customers</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-purple-600">{userData.activeSessions}</div>
            <div className="text-sm text-gray-600">Active Sessions</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-orange-600">{userData.newRegistrations}</div>
            <div className="text-sm text-gray-600">New Today</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-red-600">{userData.blockedUsers}</div>
            <div className="text-sm text-gray-600">Blocked Users</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-yellow-600">{userData.pendingVerifications}</div>
            <div className="text-sm text-gray-600">Pending</div>
          </div>
        </div>

        {/* Activity Metrics */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">User Activity</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Daily Active Users</span>
                <span className="font-semibold">{userData.dailyActiveUsers}</span>
              </div>
              <div className="flex justify-between">
                <span>Weekly Retention</span>
                <span className="font-semibold">{userData.weeklyRetention}%</span>
              </div>
              <div className="flex justify-between">
                <span>Monthly Growth</span>
                <span className="font-semibold text-green-600">+{userData.monthlyGrowth}%</span>
              </div>
            </div>
          </div>
          
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">Top Regions</h3>
            <div className="space-y-3">
              {userData.topRegions.map((region, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span>{region.name}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div className="bg-[var(--primary-color)] h-2 rounded-full" style={{width: `${region.percentage}%`}}></div>
                    </div>
                    <span className="text-sm font-semibold">{region.percentage}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Users */}
        <div className="card mb-8">
          <h3 className="text-lg font-semibold mb-4">Recent User Registrations</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Name</th>
                  <th className="text-left py-2">Type</th>
                  <th className="text-left py-2">Joined</th>
                  <th className="text-left py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {userData.recentUsers.map((user, index) => (
                  <tr key={index} className="border-b">
                    <td className="py-2">{user.name}</td>
                    <td className="py-2">{user.type}</td>
                    <td className="py-2">{user.joined}</td>
                    <td className="py-2">
                      <span className={`px-2 py-1 rounded-full text-xs ${user.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                        {user.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Export Options */}
        <div className="card">
          <h3 className="text-lg font-semibold mb-4">Export Options</h3>
          <div className="flex space-x-4">
            <button onClick={handleExportCSV} className="btn-primary flex items-center space-x-2">
              <div className="icon-download text-lg"></div>
              <span>Export CSV</span>
            </button>
            <button onClick={handleExportPDF} className="btn-secondary flex items-center space-x-2">
              <div className="icon-file-text text-lg"></div>
              <span>Export Report</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<UserManagementPage />);