function SecurityPage() {
  const [activeTab, setActiveTab] = React.useState('security');

  const handleDownloadPolicy = (type) => {
    let content = '';
    
    if (type === 'security') {
      content = `HERBTRACE SECURITY MEASURES
Generated: ${new Date().toLocaleString()}

SECURITY INFRASTRUCTURE:
• Multi-Factor Authentication: Required for all admin accounts
• End-to-End Encryption: AES-256 encryption for data at rest and in transit
• Regular Security Audits: Monthly penetration testing and vulnerability assessments
• Blockchain Immutability: Tamper-proof record keeping with cryptographic hashing
• 24/7 Threat Monitoring: Real-time security monitoring and incident response
• SSL/TLS Certificates: All communications encrypted with latest protocols
• Access Controls: Role-based permission system with principle of least privilege
• Secure Backup Systems: Daily encrypted backups with disaster recovery procedures

COMPLIANCE & CERTIFICATIONS:
• ISO 27001 Information Security Management
• SOC 2 Type II Compliance
• GDPR Data Protection Compliance
• AYUSH Regulatory Compliance
• FDA Food Safety Standards

DATA PROTECTION:
• Data Anonymization: Personal data anonymized where possible
• Secure Data Centers: Tier 4 certified data centers with physical security
• Network Segmentation: Isolated networks for different system components
• Intrusion Detection: Advanced threat detection systems
• Regular Updates: Automated security patches and updates

Last Updated: ${new Date().toLocaleDateString()}`;
    } else if (type === 'privacy') {
      content = `HERBTRACE PRIVACY POLICY
Generated: ${new Date().toLocaleString()}

DATA COLLECTION:
• User Information: Name, email, phone number, farm location
• Herb Data: Batch details, quality tests, processing methods
• Usage Analytics: Platform usage statistics (anonymized)
• Technical Data: IP addresses, device information, browser type

DATA USAGE:
• Service Delivery: Providing herb traceability and verification services
• Quality Assurance: Monitoring and improving platform performance
• Communication: Sending important updates and notifications
• Compliance: Meeting regulatory and legal requirements

USER RIGHTS (GDPR):
• Right to Access: Users can request access to their personal data
• Right to Rectification: Users can correct inaccurate personal data
• Right to Erasure: Users can request deletion of personal data
• Right to Portability: Users can export their data
• Right to Object: Users can object to certain data processing

DATA SHARING:
• No Sale of Data: We never sell personal data to third parties
• Service Providers: Limited sharing with trusted service providers
• Legal Requirements: Disclosure when required by law
• User Consent: Explicit consent required for any other sharing

COOKIES & TRACKING:
• Essential Cookies: Required for platform functionality
• Analytics Cookies: Used to improve user experience (opt-out available)
• No Third-Party Tracking: No advertising or marketing cookies

Contact: privacy@herbtrace.com
Last Updated: ${new Date().toLocaleDateString()}`;
    } else {
      content = `HERBTRACE DISCLAIMER & TERMS
Generated: ${new Date().toLocaleString()}

PLATFORM PURPOSE:
• Traceability Service: Platform provides herb traceability and verification only
• No Medical Claims: No therapeutic, medicinal, or health claims are made
• Information Only: All data provided for informational purposes only
• User Responsibility: Users responsible for accuracy of uploaded data

LIABILITY LIMITATIONS:
• Platform Limitation: HerbTrace not liable for user errors or data inaccuracies
• Third-Party Services: External services have their own terms and policies
• Force Majeure: Not liable for events beyond reasonable control
• Indirect Damages: No liability for consequential or indirect damages

USER OBLIGATIONS:
• Accurate Information: Users must provide truthful and accurate data
• Legal Compliance: Users must comply with all applicable laws
• Proper Usage: Platform must be used for legitimate purposes only
• Data Security: Users responsible for account security

INTELLECTUAL PROPERTY:
• Platform Ownership: HerbTrace owns all platform intellectual property
• User Content: Users retain rights to their uploaded content
• License Grant: Users grant license to use content for platform purposes
• Trademark Policy: Respect for third-party trademarks required

MODIFICATIONS:
• Terms Updates: Terms subject to change with notice
• Continued Use: Continued use implies acceptance of updated terms
• Notification: Users will be notified of material changes

GOVERNING LAW:
• Jurisdiction: Governed by laws of India
• Dispute Resolution: Arbitration preferred for dispute resolution
• Contact: legal@herbtrace.com

Last Updated: ${new Date().toLocaleDateString()}
Version: 2.1.0`;
    }

    const element = document.createElement('a');
    const file = new Blob([content], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `herbtrace_${type}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader title="Security & Privacy" />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-8 bg-white rounded-lg p-1">
          <button
            onClick={() => setActiveTab('security')}
            className={`flex-1 py-2 px-4 rounded-md transition-colors ${activeTab === 'security' ? 'bg-[var(--primary-color)] text-white' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            Security Measures
          </button>
          <button
            onClick={() => setActiveTab('privacy')}
            className={`flex-1 py-2 px-4 rounded-md transition-colors ${activeTab === 'privacy' ? 'bg-[var(--primary-color)] text-white' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            Privacy Policy
          </button>
          <button
            onClick={() => setActiveTab('disclaimer')}
            className={`flex-1 py-2 px-4 rounded-md transition-colors ${activeTab === 'disclaimer' ? 'bg-[var(--primary-color)] text-white' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            Disclaimer & Terms
          </button>
        </div>

        {/* Security Measures Tab */}
        {activeTab === 'security' && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="card text-center">
                <div className="text-2xl font-bold text-green-600">99.9%</div>
                <div className="text-sm text-gray-600">Uptime</div>
              </div>
              <div className="card text-center">
                <div className="text-2xl font-bold text-blue-600">AES-256</div>
                <div className="text-sm text-gray-600">Encryption</div>
              </div>
              <div className="card text-center">
                <div className="text-2xl font-bold text-purple-600">24/7</div>
                <div className="text-sm text-gray-600">Monitoring</div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Security Infrastructure</h3>
                <ul className="space-y-2 text-sm">
                  <li>• Multi-Factor Authentication</li>
                  <li>• End-to-End Encryption (AES-256)</li>
                  <li>• Regular Security Audits</li>
                  <li>• Blockchain Immutability</li>
                  <li>• 24/7 Threat Monitoring</li>
                  <li>• SSL/TLS Certificates</li>
                </ul>
              </div>
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Compliance & Certifications</h3>
                <ul className="space-y-2 text-sm">
                  <li>• ISO 27001 Certified</li>
                  <li>• SOC 2 Type II Compliant</li>
                  <li>• GDPR Data Protection</li>
                  <li>• AYUSH Regulatory Compliance</li>
                  <li>• FDA Food Safety Standards</li>
                </ul>
              </div>
            </div>

            <div className="card">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Security Documentation</h3>
                <button onClick={() => handleDownloadPolicy('security')} className="btn-primary">
                  Download Security Report
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Privacy Policy Tab */}
        {activeTab === 'privacy' && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Data We Collect</h3>
                <ul className="space-y-2 text-sm">
                  <li>• User Information (Name, Email, Phone)</li>
                  <li>• Herb Data (Batch Details, Quality Tests)</li>
                  <li>• Usage Analytics (Anonymized)</li>
                  <li>• Technical Data (IP, Browser, Device)</li>
                </ul>
              </div>
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Your Rights (GDPR)</h3>
                <ul className="space-y-2 text-sm">
                  <li>• Right to Access Your Data</li>
                  <li>• Right to Correct Inaccuracies</li>
                  <li>• Right to Delete Your Data</li>
                  <li>• Right to Export Your Data</li>
                  <li>• Right to Object Processing</li>
                </ul>
              </div>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold mb-4">Data Usage & Sharing</h3>
              <div className="grid md:grid-cols-3 gap-4 text-sm">
                <div>
                  <h4 className="font-medium text-green-600">✓ We Use Data For:</h4>
                  <ul className="mt-2 space-y-1">
                    <li>• Service delivery</li>
                    <li>• Quality assurance</li>
                    <li>• Communication</li>
                    <li>• Legal compliance</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-red-600">✗ We Never:</h4>
                  <ul className="mt-2 space-y-1">
                    <li>• Sell your data</li>
                    <li>• Share without consent</li>
                    <li>• Use for advertising</li>
                    <li>• Track across sites</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-blue-600">Contact</h4>
                  <p className="mt-2">privacy@herbtrace.com</p>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Privacy Policy Document</h3>
                <button onClick={() => handleDownloadPolicy('privacy')} className="btn-primary">
                  Download Privacy Policy
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Disclaimer & Terms Tab */}
        {activeTab === 'disclaimer' && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Platform Purpose</h3>
                <ul className="space-y-2 text-sm">
                  <li>• Herb traceability and verification service</li>
                  <li>• No medical or therapeutic claims made</li>
                  <li>• Information provided for reference only</li>
                  <li>• Users responsible for data accuracy</li>
                </ul>
              </div>
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Liability Limitations</h3>
                <ul className="space-y-2 text-sm">
                  <li>• Not liable for user errors</li>
                  <li>• Third-party services have own terms</li>
                  <li>• No liability for indirect damages</li>
                  <li>• Force majeure exclusions apply</li>
                </ul>
              </div>
            </div>

            <div className="card bg-yellow-50 border-yellow-200">
              <h3 className="text-lg font-semibold mb-4 text-yellow-800">Important Disclaimer</h3>
              <p className="text-sm text-yellow-700">
                HerbTrace is a traceability platform only. We make no medical claims about any herbs tracked through our system. 
                Always consult qualified healthcare professionals before using any herbal products. Users are responsible for 
                ensuring compliance with local regulations and the accuracy of uploaded information.
              </p>
            </div>

            <div className="card">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Terms & Disclaimer Document</h3>
                <button onClick={() => handleDownloadPolicy('disclaimer')} className="btn-primary">
                  Download Terms & Disclaimer
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<SecurityPage />);