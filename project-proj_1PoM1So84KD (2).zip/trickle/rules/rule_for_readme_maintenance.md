# Rule for README Maintenance

When project updates occur:
- Always check if README.md needs updates after implementing new features
- Update the feature list when new functionality is added
- Keep the technology stack section current with any library changes  
- Update the "Last updated" date whenever README content changes
- Ensure supported herbs list matches the actual application options
- Document any new technical requirements or setup steps
- Update user authentication details when login system changes
- Keep demo credentials current in documentation
- Update admin features documentation when new management tools are added
- Document user-specific portal functionality when implemented
