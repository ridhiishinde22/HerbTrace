# Ayurvedic Herb Traceability App

A comprehensive mobile web application for tracking Ayurvedic herbs from farm to consumer using blockchain-like verification system.

## Features

### User Authentication
- Secure login system for farmers and customers
- Demo credentials: farmer1/password123 and customer1/password123
- User session management with logout functionality
- User-specific portals with individual data storage
- Personalized dashboards based on email/username

### Farmer Portal
- Personal dashboard with collection statistics
- Add herb collections with detailed information
- GPS location capture for farm verification  
- Photo upload for herb documentation
- Generate QR codes for each batch
- Copy batch ID functionality for sharing
- View all collections with verification status
- Blockchain registration simulation

### Customer Portal
- QR code scanning for herb verification
- Manual batch ID entry option
- Recent verification history tracking
- Complete herb traceability information
- Interactive farm location maps
- Blockchain proof verification
- Verification tips and guidelines

### Technical Features
- Mobile-first responsive design with PWA capabilities
- Real-time GPS location services
- Camera integration for QR scanning
- Database integration with Trickle DB
- User authentication and session management
- Local storage for verification history
- Offline-capable design patterns

## Supported Herbs
- Ashwagandha
- Tulsi  
- Neem
- Giloy
- Amla
- Brahmi
- Shatavari
- Haritaki
- Arjuna
- Mulethi

## Technology Stack
- Frontend: React 18 with modern hooks
- Styling: TailwindCSS with custom design system
- Database: Trickle Database for persistence
- QR Codes: QRious and QR-Scanner libraries
- Maps: OpenStreetMap integration
- Icons: Lucide icon font
- Authentication: Trickle Database user system

### Admin Portal
- Comprehensive system analytics and user management
- Data export functionality (CSV format)
- Downloadable analytics reports
- Security and privacy policy management
- Real-time system health monitoring
- User activity tracking and statistics

## Demo Users
- **Farmer**: Any email and password (e.g., riya@gmail.com creates "Riya" portal)
- **Customer**: Any email and password (e.g., ram@gmail.com creates "Ram" portal)
- **Admin**: Any email and password for system management access

## Getting Started
The app is ready to use immediately - no build process required. Simply open index.html in a modern web browser.

*Last updated: September 19, 2025*
