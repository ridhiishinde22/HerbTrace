function QRGenerator({ batchId, onBack }) {
  try {
    const canvasRef = React.useRef();
    const [qrReady, setQrReady] = React.useState(false);
    const [qrError, setQrError] = React.useState(null);
    
    React.useEffect(() => {
      console.log('QRGenerator: Checking for QRious library...');
      
      // Check if QRious library is loaded
      const checkQRious = () => {
        const hasQRious = typeof window.QRious !== 'undefined';
        
        console.log('QRious available:', hasQRious);
        console.log('Available window QR properties:', Object.keys(window).filter(k => k.toLowerCase().includes('qr')));
        
        if (hasQRious) {
          console.log('QRious library is ready');
          setQrReady(true);
          return true;
        }
        return false;
      };

      // Try immediately - library might already be loaded
      if (checkQRious()) {
        return;
      }

      // If not loaded immediately, wait for DOM to be ready and retry
      let attempts = 0;
      const maxAttempts = 10;
      const checkInterval = 200;
      
      const interval = setInterval(() => {
        attempts++;
        console.log(`QRious check attempt ${attempts}/${maxAttempts}`);
        
        if (checkQRious()) {
          clearInterval(interval);
        } else if (attempts >= maxAttempts) {
          clearInterval(interval);
          console.error('QRious library failed to load after maximum attempts');
          setQrError('QR code library unavailable. Please use the Batch ID instead.');
        }
      }, checkInterval);

      return () => clearInterval(interval);
    }, []);

    React.useEffect(() => {
      console.log('QRGenerator: Attempting to generate QR code');
      console.log('Conditions:', { batchId: !!batchId, canvas: !!canvasRef.current, qrReady, hasQRious: !!window.QRious });
      
      if (batchId && canvasRef.current && qrReady && window.QRious) {
        try {
          console.log('Generating QR code for batch ID:', batchId);
          
          // Create QR code using QRious
          const qr = new window.QRious({
            element: canvasRef.current,
            value: batchId,
            size: 200,
            foreground: '#22c55e',
            background: '#ffffff'
          });
          
          console.log('QR code generated successfully');
          
        } catch (error) {
          console.error('Error generating QR code:', error);
          setQrError('Error generating QR code: ' + error.message);
        }
      }
    }, [batchId, qrReady]);

    return (
      <div className="min-h-screen bg-gray-50" data-name="qr-generator" data-file="components/QRGenerator.js">
        <Header title="QR Code Generated" onBack={onBack} />
        
        <div className="p-6">
          <div className="card text-center space-y-6">
            <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto">
              <div className="icon-check-circle text-2xl text-[var(--primary-color)]"></div>
            </div>
            
            <div>
              <h2 className="text-xl font-bold text-[var(--text-primary)] mb-2">
                Herb Added Successfully!
              </h2>
              <p className="text-[var(--text-secondary)]">
                Your herb has been registered on the blockchain
              </p>
            </div>

            <div className="bg-gray-50 p-6 rounded-xl">
              <p className="text-sm font-medium text-[var(--text-primary)] mb-4">
                Batch ID: <span className="text-[var(--primary-color)]">{batchId}</span>
              </p>
              {qrError ? (
                <div className="w-[200px] h-[200px] bg-red-50 border-2 border-red-300 rounded-lg shadow-md mx-auto flex items-center justify-center">
                  <div className="text-center p-4">
                    <div className="icon-alert-circle text-2xl text-red-500 mb-2"></div>
                    <p className="text-xs text-red-600">{qrError}</p>
                    <p className="text-xs text-gray-500 mt-2">Use batch ID: {batchId}</p>
                  </div>
                </div>
              ) : qrReady ? (
                <canvas ref={canvasRef} width="200" height="200" className="mx-auto border-2 border-white rounded-lg shadow-md"></canvas>
              ) : (
                <div className="w-[200px] h-[200px] bg-white border-2 border-gray-300 rounded-lg shadow-md mx-auto flex items-center justify-center">
                  <div className="text-center">
                    <div className="icon-loader-2 text-2xl text-[var(--primary-color)] animate-spin mb-2"></div>
                    <p className="text-xs text-gray-500">Loading QR Generator...</p>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <p className="text-sm text-[var(--text-secondary)]">
                Share this QR code with your customers for herb verification
              </p>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => {
                    if (canvasRef.current && qrReady && !qrError) {
                      try {
                        const canvas = canvasRef.current;
                        const link = document.createElement('a');
                        link.download = `herb-qr-${batchId}.png`;
                        link.href = canvas.toDataURL();
                        link.click();
                      } catch (error) {
                        console.error('Download error:', error);
                        alert('Error downloading QR code. Please try again.');
                      }
                    } else {
                      alert('QR code not available for download.');
                    }
                  }}
                  disabled={!qrReady || qrError}
                  className={`flex-1 btn-secondary flex items-center justify-center space-x-2 ${(!qrReady || qrError) ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <div className="icon-download text-lg"></div>
                  <span>Download QR</span>
                </button>
                
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(batchId).then(() => {
                      alert('Batch ID copied: ' + batchId);
                    }).catch(() => {
                      alert('Batch ID: ' + batchId);
                    });
                  }}
                  className="flex-1 btn-primary flex items-center justify-center space-x-2"
                >
                  <div className="icon-copy text-lg"></div>
                  <span>Copy Batch ID</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('QRGenerator component error:', error);
    return null;
  }
}