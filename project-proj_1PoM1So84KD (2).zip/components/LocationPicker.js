function LocationPicker({ onLocationSelect, onBack }) {
  try {
    const [location, setLocation] = React.useState({
      latitude: 28.6139, // Default to Delhi
      longitude: 77.2090,
      region: '',
      state: '',
      country: 'India',
      farmType: 'Organic Farm'
    });
    const [loading, setLoading] = React.useState(false);

    const handleConfirmLocation = () => {
      onLocationSelect({
        latitude: location.latitude,
        longitude: location.longitude,
        region: location.region,
        state: location.state,
        country: location.country,
        farmType: location.farmType,
        accuracy: 10,
        timestamp: new Date().toISOString(),
        manual: true
      });
    };

    return (
      <div className="min-h-screen bg-gray-50" data-name="location-picker" data-file="components/LocationPicker.js">
        <Header title="Select Location" onBack={onBack} />
        
        <div className="p-4 space-y-4">
          <div className="card space-y-4">
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">
              Choose Farm Location
            </h3>
            
            {/* Manual Location Entry */}
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                    Region
                  </label>
                  <input
                    type="text"
                    value={location.region}
                    onChange={(e) => setLocation(prev => ({ ...prev, region: e.target.value }))}
                    className="input-field text-sm"
                    placeholder="e.g., Northern Plains"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                    State
                  </label>
                  <input
                    type="text"
                    value={location.state}
                    onChange={(e) => setLocation(prev => ({ ...prev, state: e.target.value }))}
                    className="input-field text-sm"
                    placeholder="e.g., Punjab"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                    Country
                  </label>
                  <input
                    type="text"
                    value={location.country}
                    onChange={(e) => setLocation(prev => ({ ...prev, country: e.target.value }))}
                    className="input-field text-sm"
                    placeholder="e.g., India"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                    Farm Type
                  </label>
                  <select
                    value={location.farmType}
                    onChange={(e) => setLocation(prev => ({ ...prev, farmType: e.target.value }))}
                    className="input-field text-sm"
                  >
                    <option value="Organic Farm">Organic Farm</option>
                    <option value="Traditional Farm">Traditional Farm</option>
                    <option value="Greenhouse Farm">Greenhouse Farm</option>
                    <option value="Hydroponic Farm">Hydroponic Farm</option>
                  </select>
                </div>
              </div>

              {/* GPS Coordinates */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                    Latitude
                  </label>
                  <input
                    type="number"
                    value={location.latitude}
                    onChange={(e) => setLocation(prev => ({ ...prev, latitude: parseFloat(e.target.value) }))}
                    className="input-field text-sm"
                    step="0.000001"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                    Longitude
                  </label>
                  <input
                    type="number"
                    value={location.longitude}
                    onChange={(e) => setLocation(prev => ({ ...prev, longitude: parseFloat(e.target.value) }))}
                    className="input-field text-sm"
                    step="0.000001"
                  />
                </div>
              </div>
            </div>

            {/* Map Preview */}
            <div className="w-full h-64 rounded-lg overflow-hidden border border-[var(--border-color)]">
              <iframe
                src={`https://www.openstreetmap.org/export/embed.html?bbox=${location.longitude-0.01},${location.latitude-0.01},${location.longitude+0.01},${location.latitude+0.01}&layer=mapnik&marker=${location.latitude},${location.longitude}`}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                title="Location Selection Map"
              ></iframe>
            </div>

            <div className="text-sm text-[var(--text-secondary)] text-center">
              <p>Adjust coordinates above or use GPS for current location</p>
            </div>

            <button
              onClick={handleConfirmLocation}
              className="w-full btn-primary flex items-center justify-center space-x-2"
            >
              <div className="icon-map-pin text-lg"></div>
              <span>Confirm Location</span>
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('LocationPicker component error:', error);
    return null;
  }
}