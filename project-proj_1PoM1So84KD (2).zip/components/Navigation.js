function Navigation({ onNavigate, currentPage }) {
  try {
    const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
    
    const navItems = [
      { id: 'dashboard', label: 'Home', icon: 'home' },
      { id: 'about', label: 'About', icon: 'info' },
      { id: 'features', label: 'Features', icon: 'star' },
      { id: 'qa-results', label: 'QA Results', icon: 'check-circle' },
      { id: 'stakeholders', label: 'Stakeholders', icon: 'users' },
      { id: 'compliance', label: 'Compliance', icon: 'shield-check' },
      { id: 'contact', label: 'Contact', icon: 'phone' }
    ];

    return (
      <nav className="bg-white shadow-md sticky top-0 z-50" data-name="navigation" data-file="components/Navigation.js">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div 
              className="flex items-center space-x-3 cursor-pointer"
              onClick={() => onNavigate('dashboard')}
            >
              <div className="w-10 h-10 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-leaf text-lg text-white"></div>
              </div>
              <span className="text-xl font-bold text-gray-900">HerbTrace</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`flex items-center space-x-1 px-3 py-2 rounded-md transition-colors ${
                    currentPage === item.id 
                      ? 'text-[var(--primary-color)] bg-[var(--secondary-color)]' 
                      : 'text-gray-600 hover:text-[var(--primary-color)]'
                  }`}
                >
                  <div className={`icon-${item.icon} text-lg`}></div>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <div className={`icon-${mobileMenuOpen ? 'x' : 'menu'} text-xl text-gray-600`}></div>
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200 py-4">
              {navItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 px-4 py-3 text-left transition-colors ${
                    currentPage === item.id 
                      ? 'text-[var(--primary-color)] bg-[var(--secondary-color)]' 
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <div className={`icon-${item.icon} text-lg`}></div>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </nav>
    );
  } catch (error) {
    console.error('Navigation component error:', error);
    return null;
  }
}