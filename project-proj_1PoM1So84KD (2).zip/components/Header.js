function Header({ title, onBack }) {
  try {
    return (
      <div className="mobile-header" data-name="header" data-file="components/Header.js">
        <div className="flex items-center space-x-3">
          {onBack && (
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <div className="icon-arrow-left text-xl text-[var(--text-primary)]"></div>
            </button>
          )}
          <h1 className="text-lg font-semibold text-[var(--text-primary)]">{title}</h1>
        </div>
        
        <div className="w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
          <div className="icon-leaf text-sm text-white"></div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}