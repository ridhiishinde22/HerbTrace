function CustomerDashboard({ currentUser, onNavigate, onLogout }) {
  try {
    const [recentScans, setRecentScans] = React.useState([]);
    const [loading, setLoading] = React.useState(false);

    React.useEffect(() => {
      // Load recent scans from user-specific localStorage
      const userKey = `recentHerbScans_${currentUser?.userId || 'default'}`;
      const savedScans = localStorage.getItem(userKey);
      if (savedScans) {
        try {
          setRecentScans(JSON.parse(savedScans));
        } catch (error) {
          console.error('Error parsing saved scans:', error);
        }
      }
    }, [currentUser]);

    const handleQuickScan = () => {
      onNavigate('qr-scanner');
    };

    const handleManualVerify = () => {
      const batchId = prompt('Enter Batch ID:');
      if (batchId) {
        verifyHerbById(batchId);
      }
    };

    const verifyHerbById = async (batchId) => {
      setLoading(true);
      try {
        const herbData = await getHerbFromDatabase(batchId);
        if (herbData) {
          // Save to user-specific recent scans
          const newScan = {
            ...herbData,
            scannedAt: new Date().toISOString(),
            scannedBy: currentUser?.userId
          };
          
          const updatedScans = [newScan, ...recentScans.slice(0, 4)];
          setRecentScans(updatedScans);
          const userKey = `recentHerbScans_${currentUser?.userId || 'default'}`;
          localStorage.setItem(userKey, JSON.stringify(updatedScans));
          
          onNavigate('herb-details', herbData);
        } else {
          alert('Herb not found. Please check the batch ID.');
        }
      } catch (error) {
        alert('Error verifying herb. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    return (
      <div className="min-h-screen bg-gray-50" data-name="customer-dashboard" data-file="components/CustomerDashboard.js">
        <div className="mobile-header">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
              <div className="icon-user text-sm text-white"></div>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-[var(--text-primary)]">Customer Portal</h1>
              <p className="text-xs text-[var(--text-secondary)]">Welcome, {currentUser?.fullName}</p>
            </div>
          </div>
          <button onClick={onLogout} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <div className="icon-log-out text-xl text-[var(--text-primary)]"></div>
          </button>
        </div>

        <div className="p-4 space-y-6">
          {/* Verification Options */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Verify Your Herbs</h3>
            
            <button
              onClick={handleQuickScan}
              className="w-full btn-primary flex items-center justify-center space-x-3"
            >
              <div className="icon-camera text-xl"></div>
              <span>Scan QR Code</span>
            </button>
            
            <button
              onClick={handleManualVerify}
              disabled={loading}
              className="w-full btn-secondary flex items-center justify-center space-x-3"
            >
              {loading ? (
                <div className="icon-loader-2 text-xl animate-spin"></div>
              ) : (
                <div className="icon-edit text-xl"></div>
              )}
              <span>Enter Batch ID</span>
            </button>
          </div>

          {/* Recent Verifications */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Recent Verifications</h3>
            
            {recentScans.length === 0 ? (
              <div className="card text-center py-8">
                <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="icon-shield-check text-2xl text-[var(--primary-color)]"></div>
                </div>
                <h4 className="font-semibold text-[var(--text-primary)] mb-2">No Verifications Yet</h4>
                <p className="text-sm text-[var(--text-secondary)] mb-4">Start verifying herbs to build your trust history</p>
                <button
                  onClick={handleQuickScan}
                  className="btn-primary text-sm"
                >
                  Scan First Herb
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {recentScans.map((scan, index) => (
                  <div key={`${scan.batchId}-${index}`} className="bg-white rounded-lg p-4 shadow-sm border hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                          <div className="icon-shield-check text-lg text-green-600"></div>
                        </div>
                        <div>
                          <h4 className="font-semibold text-[var(--text-primary)]">{scan.herbName}</h4>
                          <p className="text-sm text-[var(--text-secondary)]">{scan.quantity} kg • By {scan.farmerName}</p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end space-y-1">
                        <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                          ✓ Authentic
                        </span>
                        {scan.organicCertified && (
                          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                            🌱 Organic
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center text-xs text-[var(--text-secondary)] mb-2">
                      <span>Batch: {scan.batchId}</span>
                      <span>Verified: {new Date(scan.scannedAt).toLocaleDateString()}</span>
                    </div>
                    
                    <button
                      onClick={() => onNavigate('herb-details', scan)}
                      className="w-full text-xs text-[var(--primary-color)] hover:bg-[var(--secondary-color)] py-2 rounded-lg transition-colors"
                    >
                      View Full Details & Location →
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Tips Section */}
          <div className="bg-[var(--secondary-color)] rounded-lg p-4">
            <h4 className="font-semibold text-[var(--text-primary)] mb-2 flex items-center space-x-2">
              <div className="icon-info text-lg text-[var(--primary-color)]"></div>
              <span>Verification Tips</span>
            </h4>
            <ul className="text-sm text-[var(--text-secondary)] space-y-1">
              <li>• Always verify herbs before consumption</li>
              <li>• Check the harvest date and farm location</li>
              <li>• Authentic herbs will show ✓ Verified status</li>
              <li>• Contact us if verification fails</li>
            </ul>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('CustomerDashboard component error:', error);
    return null;
  }
}