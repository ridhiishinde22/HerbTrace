function AdminDashboard({ currentUser, onLogout }) {
  try {
    const [analytics, setAnalytics] = React.useState({
      totalFarmers: 0,
      totalCustomers: 0,
      totalHerbs: 0,
      totalVerifications: 0,
      recentActivities: []
    });
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
      loadAnalytics();
    }, []);

    const loadAnalytics = async () => {
      try {
        // Get herbs data
        const herbsResult = await trickleListObjects(HERB_OBJECT_TYPE, 1000, true);
        const herbs = herbsResult.items;

        // Calculate verifications from localStorage across all users
        let totalVerifications = 0;
        try {
          const savedScans = localStorage.getItem('recentHerbScans');
          if (savedScans) {
            totalVerifications = JSON.parse(savedScans).length;
          }
        } catch (error) {
          console.error('Error parsing verification data:', error);
        }

        // Recent activities
        const recentActivities = herbs.slice(0, 10).map(herb => ({
          type: 'herb_added',
          message: `${herb.objectData.farmerName} added ${herb.objectData.herbName}`,
          timestamp: herb.createdAt,
          batchId: herb.objectData.batchId
        }));

        setAnalytics({
          totalFarmers: 12, // Simulated count
          totalCustomers: 85, // Simulated count  
          totalHerbs: herbs.length,
          totalVerifications,
          recentActivities
        });
      } catch (error) {
        console.error('Error loading analytics:', error);
      } finally {
        setLoading(false);
      }
    };



    return (
      <div className="min-h-screen bg-gray-50" data-name="admin-dashboard" data-file="components/AdminDashboard.js">
        <div className="mobile-header">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
              <div className="icon-settings text-sm text-white"></div>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-[var(--text-primary)]">Admin Portal</h1>
              <p className="text-xs text-[var(--text-secondary)]">Welcome, {currentUser?.fullName}</p>
            </div>
          </div>
          <button onClick={onLogout} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <div className="icon-log-out text-xl text-[var(--text-primary)]"></div>
          </button>
        </div>

        <div className="p-4 space-y-6">
          {/* Analytics Overview */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white rounded-lg p-4 shadow-sm text-center">
              <div className="text-2xl font-bold text-blue-600">{analytics.totalFarmers}</div>
              <div className="text-xs text-[var(--text-secondary)]">Total Farmers</div>
              <div className="icon-users text-lg text-blue-600 mt-1"></div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm text-center">
              <div className="text-2xl font-bold text-green-600">{analytics.totalCustomers}</div>
              <div className="text-xs text-[var(--text-secondary)]">Total Customers</div>
              <div className="icon-user-check text-lg text-green-600 mt-1"></div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm text-center">
              <div className="text-2xl font-bold text-[var(--primary-color)]">{analytics.totalHerbs}</div>
              <div className="text-xs text-[var(--text-secondary)]">Herbs Registered</div>
              <div className="icon-leaf text-lg text-[var(--primary-color)] mt-1"></div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm text-center">
              <div className="text-2xl font-bold text-purple-600">{analytics.totalVerifications}</div>
              <div className="text-xs text-[var(--text-secondary)]">Verifications</div>
              <div className="icon-shield-check text-lg text-purple-600 mt-1"></div>
            </div>
          </div>

          {/* System Health */}
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-3 flex items-center">
              <div className="icon-activity text-lg text-[var(--primary-color)] mr-2"></div>
              System Health
            </h3>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-[var(--text-secondary)]">Database</span>
                <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded-full">✓ Online</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-[var(--text-secondary)]">QR Generation</span>
                <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded-full">✓ Active</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-[var(--text-secondary)]">Authentication</span>
                <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded-full">✓ Secure</span>
              </div>
            </div>
          </div>

          {/* Recent Activities */}
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-3 flex items-center">
              <div className="icon-clock text-lg text-[var(--primary-color)] mr-2"></div>
              Recent Activities
            </h3>
            {loading ? (
              <div className="text-center py-4">
                <div className="icon-loader-2 text-xl text-[var(--primary-color)] animate-spin"></div>
              </div>
            ) : analytics.recentActivities.length === 0 ? (
              <p className="text-[var(--text-secondary)] text-center py-4">No recent activities</p>
            ) : (
              <div className="space-y-3">
                {analytics.recentActivities.map((activity, index) => (
                  <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-sm text-[var(--text-primary)]">{activity.message}</p>
                      <p className="text-xs text-[var(--text-secondary)]">{new Date(activity.timestamp).toLocaleDateString()}</p>
                    </div>
                    <div className="icon-leaf text-lg text-[var(--primary-color)]"></div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Management Actions */}
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-3 flex items-center">
              <div className="icon-cog text-lg text-[var(--primary-color)] mr-2"></div>
              System Management
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => window.location.href = 'admin-user-management.html'}
                className="p-3 bg-blue-50 rounded-lg text-center hover:bg-blue-100 transition-colors"
              >
                <div className="icon-users text-xl text-blue-600 mb-2"></div>
                <span className="text-xs text-blue-800">User Management</span>
              </button>
              <button 
                onClick={() => window.location.href = 'admin-data-export.html'}
                className="p-3 bg-green-50 rounded-lg text-center hover:bg-green-100 transition-colors"
              >
                <div className="icon-database text-xl text-green-600 mb-2"></div>
                <span className="text-xs text-green-800">Data Export</span>
              </button>
              <button 
                onClick={() => window.location.href = 'admin-analytics.html'}
                className="p-3 bg-purple-50 rounded-lg text-center hover:bg-purple-100 transition-colors"
              >
                <div className="icon-bar-chart text-xl text-purple-600 mb-2"></div>
                <span className="text-xs text-purple-800">Analytics Report</span>
              </button>
              <button 
                onClick={() => window.location.href = 'admin-security.html'}
                className="p-3 bg-red-50 rounded-lg text-center hover:bg-red-100 transition-colors"
              >
                <div className="icon-shield text-xl text-red-600 mb-2"></div>
                <span className="text-xs text-red-800">Security & Privacy</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AdminDashboard component error:', error);
    return null;
  }
}