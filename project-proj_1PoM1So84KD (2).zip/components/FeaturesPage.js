function FeaturesPage({ onNavigate }) {
  try {
    return (
      <div className="min-h-screen" data-name="features-page" data-file="components/FeaturesPage.js">
        <Navigation onNavigate={onNavigate} currentPage="features" />
        
        <div className="max-w-7xl mx-auto px-4 py-16">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">Platform Features</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover the comprehensive features that make our herb traceability platform 
              the most trusted solution in the industry.
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center mb-4">
                <div className="icon-qr-code text-xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-semibold mb-3">QR Code Generation</h3>
              <p className="text-gray-600">Generate unique QR codes for each herb batch with blockchain verification.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center mb-4">
                <div className="icon-map-pin text-xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-semibold mb-3">GPS Tracking</h3>
              <p className="text-gray-600">Precise GPS location tracking of farm origins with interactive maps.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center mb-4">
                <div className="icon-shield-check text-xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-semibold mb-3">Authenticity Verification</h3>
              <p className="text-gray-600">Instant verification of herb authenticity through blockchain technology.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center mb-4">
                <div className="icon-test-tube text-xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-semibold mb-3">Quality Testing</h3>
              <p className="text-gray-600">Comprehensive quality tests including purity, heavy metals, and pesticides.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center mb-4">
                <div className="icon-leaf text-xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-semibold mb-3">Organic Certification</h3>
              <p className="text-gray-600">Digital organic certification tracking and verification system.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center mb-4">
                <div className="icon-bar-chart text-xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-semibold mb-3">Analytics Dashboard</h3>
              <p className="text-gray-600">Comprehensive analytics and reporting for farmers and administrators.</p>
            </div>
          </div>

          {/* Process Flow */}
          <div className="bg-gradient-to-r from-[var(--secondary-color)] to-green-50 p-8 rounded-xl">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">How It Works</h2>
            <div className="grid md:grid-cols-4 gap-6 text-center">
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-[var(--primary-color)] rounded-full flex items-center justify-center text-white font-bold text-xl mb-4">1</div>
                <h3 className="font-semibold mb-2">Farm Registration</h3>
                <p className="text-sm text-gray-600">Farmers register herbs with GPS location and quality details</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-[var(--primary-color)] rounded-full flex items-center justify-center text-white font-bold text-xl mb-4">2</div>
                <h3 className="font-semibold mb-2">QR Generation</h3>
                <p className="text-sm text-gray-600">Unique QR codes generated with blockchain verification</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-[var(--primary-color)] rounded-full flex items-center justify-center text-white font-bold text-xl mb-4">3</div>
                <h3 className="font-semibold mb-2">Customer Scan</h3>
                <p className="text-sm text-gray-600">Customers scan QR codes to verify authenticity</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-[var(--primary-color)] rounded-full flex items-center justify-center text-white font-bold text-xl mb-4">4</div>
                <h3 className="font-semibold mb-2">Trust Verified</h3>
                <p className="text-sm text-gray-600">Complete transparency from farm to consumer</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('FeaturesPage component error:', error);
    return null;
  }
}