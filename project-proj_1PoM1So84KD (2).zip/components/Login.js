function Login({ userType, onLogin, onBack }) {
  try {
    const [formData, setFormData] = React.useState({
      email: '',
      password: ''
    });
    const [loading, setLoading] = React.useState(false);

    const handleSubmit = async (e) => {
      e.preventDefault();
      setLoading(true);

      try {
        const user = await authenticateUser(formData.email, formData.password, userType);
        if (user) {
          onLogin(user);
        } else {
          alert('Invalid credentials. Please try again.');
        }
      } catch (error) {
        alert('Login failed. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    return (
      <div className="min-h-screen bg-gray-50" data-name="login" data-file="components/Login.js">
        <Header 
          title={`${userType === 'farmer' ? 'Farmer' : 'Customer'} Login`} 
          onBack={onBack} 
        />
        
        <div className="p-6 flex items-center justify-center min-h-[calc(100vh-70px)]">
          <div className="w-full max-w-sm">
            <div className="card space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className={`text-2xl text-[var(--primary-color)] ${userType === 'farmer' ? 'icon-sprout' : userType === 'admin' ? 'icon-settings' : 'icon-user'}`}></div>
                </div>
                <h2 className="text-xl font-bold text-[var(--text-primary)]">
                  Welcome {userType === 'farmer' ? 'Farmer' : userType === 'admin' ? 'Admin' : 'Customer'}
                </h2>
                <p className="text-[var(--text-secondary)] text-sm mt-2">
                  Sign in to access your portal
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    className="input-field"
                    placeholder="Enter email address"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                    className="input-field"
                    placeholder="Enter password"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full btn-primary flex items-center justify-center space-x-2"
                >
                  {loading ? (
                    <>
                      <div className="icon-loader-2 text-lg animate-spin"></div>
                      <span>Signing in...</span>
                    </>
                  ) : (
                    <>
                      <div className="icon-log-in text-lg"></div>
                      <span>Sign In</span>
                    </>
                  )}
                </button>
              </form>

              <div className="text-center text-sm text-[var(--text-secondary)]">
                <p>Easy Access:</p>
                <p className="font-mono text-xs">
                  Use any email and password to login
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Login component error:', error);
    return null;
  }
}