function Footer({ onNavigate }) {
  try {
    return (
      <footer className="bg-gray-900 text-white py-12" data-name="footer" data-file="components/Footer.js">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                  <div className="icon-leaf text-lg text-white"></div>
                </div>
                <span className="text-xl font-bold">HerbTrace</span>
              </div>
              <p className="text-gray-400 text-sm">
                Revolutionizing Ayurvedic herb traceability through blockchain technology.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <div className="space-y-2">
                <button onClick={() => onNavigate('dashboard')} className="block text-gray-400 hover:text-white text-sm">Home</button>
                <button onClick={() => onNavigate('about')} className="block text-gray-400 hover:text-white text-sm">About</button>
                <button onClick={() => onNavigate('features')} className="block text-gray-400 hover:text-white text-sm">Features</button>
                <button onClick={() => onNavigate('contact')} className="block text-gray-400 hover:text-white text-sm">Contact</button>
              </div>
            </div>

            {/* Portals */}
            <div>
              <h3 className="font-semibold mb-4">Portals</h3>
              <div className="space-y-2">
                <button onClick={() => onNavigate('login-farmer')} className="block text-gray-400 hover:text-white text-sm">Farmer Portal</button>
                <button onClick={() => onNavigate('login-customer')} className="block text-gray-400 hover:text-white text-sm">Customer Portal</button>
                <button onClick={() => onNavigate('login-admin')} className="block text-gray-400 hover:text-white text-sm">Admin Portal</button>
              </div>
            </div>

            {/* Contact & Social */}
            <div>
              <h3 className="font-semibold mb-4">Connect</h3>
              <div className="space-y-2 mb-4">
                <p className="text-gray-400 text-sm">support@herbtrace.com</p>
                <p className="text-gray-400 text-sm">+91 98765 43210</p>
              </div>
              <div className="flex space-x-3">
                <a href="https://instagram.com/herbtrace" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-pink-400">
                  <div className="icon-instagram text-xl"></div>
                </a>
                <a href="https://facebook.com/herbtrace" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-400">
                  <div className="icon-facebook text-xl"></div>
                </a>
                <a href="https://wa.me/919876543210" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-green-400">
                  <div className="icon-message-circle text-xl"></div>
                </a>
                <a href="https://twitter.com/herbtrace" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-sky-400">
                  <div className="icon-twitter text-xl"></div>
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p className="text-gray-400 text-sm">
              © 2025 HerbTrace. All rights reserved. | Privacy Policy | Terms of Service
            </p>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}