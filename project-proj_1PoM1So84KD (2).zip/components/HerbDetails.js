function HerbDetails({ herbData, onBack }) {
  try {
    if (!herbData) {
      return (
        <div className="min-h-screen bg-gray-50">
          <Header title="Herb Details" onBack={onBack} />
          <div className="p-6">
            <div className="card text-center">
              <p className="text-[var(--text-secondary)]">No herb data available</p>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gray-50" data-name="herb-details" data-file="components/HerbDetails.js">
        <Header title="Herb Verification" onBack={onBack} />
        
        <div className="p-6 space-y-6">
          {/* Verification Status */}
          <div className="card text-center space-y-4">
            <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto">
              <div className="icon-shield-check text-2xl text-[var(--primary-color)]"></div>
            </div>
            <div>
              <h2 className="text-xl font-bold text-[var(--primary-color)]">
                ✓ Verified Authentic
              </h2>
              <p className="text-sm text-[var(--text-secondary)]">
                This herb has been verified on the blockchain
              </p>
            </div>
          </div>

          {/* Herb Information */}
          <div className="card space-y-4">
            <h3 className="text-lg font-semibold text-[var(--text-primary)] border-b border-[var(--border-color)] pb-2">
              Herb Information
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-[var(--text-secondary)]">Herb Name</p>
                <p className="font-semibold text-[var(--text-primary)]">{herbData.herbName}</p>
              </div>
              <div>
                <p className="text-sm text-[var(--text-secondary)]">Quantity</p>
                <p className="font-semibold text-[var(--text-primary)]">{herbData.quantity} kg</p>
              </div>
              <div>
                <p className="text-sm text-[var(--text-secondary)]">Batch ID</p>
                <p className="font-semibold text-[var(--primary-color)]">{herbData.batchId}</p>
              </div>
              <div>
                <p className="text-sm text-[var(--text-secondary)]">Harvest Date</p>
                <p className="font-semibold text-[var(--text-primary)]">{herbData.harvestDate}</p>
              </div>
              <div>
                <p className="text-sm text-[var(--text-secondary)]">Farmer Name</p>
                <p className="font-semibold text-[var(--text-primary)]">{herbData.farmerName || 'Unknown'}</p>
              </div>
              <div>
                <p className="text-sm text-[var(--text-secondary)]">Quality Grade</p>
                <p className="font-semibold text-[var(--text-primary)]">{herbData.qualityGrade || 'Standard'}</p>
              </div>
            </div>

            <div className="space-y-3">
              {herbData.organicCertified && (
                <div className="flex items-center space-x-2 bg-green-50 p-2 rounded">
                  <div className="icon-shield-check text-green-600"></div>
                  <span className="text-sm font-medium text-green-800">Organically Certified</span>
                </div>
              )}

              {herbData.processing && herbData.processing.length > 0 && (
                <div>
                  <p className="text-sm text-[var(--text-secondary)] mb-2">Processing Methods</p>
                  <div className="flex flex-wrap gap-1">
                    {herbData.processing.map((method, index) => (
                      <span key={index} className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        {method}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {herbData.testing && herbData.testing.length > 0 && (
                <div>
                  <p className="text-sm text-[var(--text-secondary)] mb-2">Quality Tests</p>
                  <div className="flex flex-wrap gap-1">
                    {herbData.testing.map((test, index) => (
                      <span key={index} className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">
                        {test}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {herbData.photo && (
              <div>
                <p className="text-sm text-[var(--text-secondary)] mb-2">Herb Photo</p>
                <img src={herbData.photo} alt={herbData.herbName} className="w-full h-32 object-cover rounded-lg" />
              </div>
            )}
          </div>

          {/* Location Details */}
          {herbData.location && (
            <div className="card space-y-4">
              <h3 className="text-lg font-semibold text-[var(--text-primary)] border-b border-[var(--border-color)] pb-2">
                Farm Location Details
              </h3>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Region</p>
                  <p className="font-medium text-[var(--text-primary)]">{herbData.location.region || 'Northern Plains'}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">State</p>
                  <p className="font-medium text-[var(--text-primary)]">{herbData.location.state || 'Punjab'}, {herbData.location.country || 'India'}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Country</p>
                  <p className="font-medium text-[var(--text-primary)]">{herbData.location.country || 'India'}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Farm Type</p>
                  <p className="font-medium text-[var(--text-primary)]">{herbData.location.farmType || 'Organic Farm'}</p>
                </div>
              </div>
              <MapView location={herbData.location} />
            </div>
          )}

          {/* Blockchain Proof */}
          <div className="card space-y-4">
            <h3 className="text-lg font-semibold text-[var(--text-primary)] border-b border-[var(--border-color)] pb-2">
              Blockchain Verification
            </h3>
            <div className="bg-[var(--secondary-color)] p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <div className="icon-link text-lg text-[var(--primary-color)]"></div>
                <span className="text-sm font-medium text-[var(--text-primary)]">Transaction Hash</span>
              </div>
              <p className="text-xs font-mono text-[var(--text-secondary)] break-all bg-white p-2 rounded border">
                {herbData.blockchainHash}
              </p>
            </div>
            <div className="text-center">
              <span className="text-sm text-[var(--primary-color)] font-medium">✓ Verified on Blockchain</span>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('HerbDetails component error:', error);
    return null;
  }
}
