function QRScanner({ onNavigate, onBack }) {
  try {
    const [scanning, setScanning] = React.useState(false);
    const [manualInput, setManualInput] = React.useState('');
    const videoRef = React.useRef();
    const scannerRef = React.useRef();

    const startScanning = async () => {
      try {
        setScanning(true);
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
          
          // Initialize QR scanner
          scannerRef.current = new QrScanner(
            videoRef.current,
            result => handleScanResult(result.data),
            { returnDetailedScanResult: true }
          );
          scannerRef.current.start();
        }
      } catch (error) {
        alert('Camera access denied. Please use manual input instead.');
        setScanning(false);
      }
    };

    const stopScanning = () => {
      if (scannerRef.current) {
        scannerRef.current.stop();
        scannerRef.current.destroy();
      }
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = videoRef.current.srcObject.getTracks();
        tracks.forEach(track => track.stop());
      }
      setScanning(false);
    };

    const handleScanResult = async (batchId) => {
      stopScanning();
      await verifyHerb(batchId);
    };

    const handleManualVerify = async () => {
      if (!manualInput.trim()) {
        alert('Please enter a batch ID');
        return;
      }
      await verifyHerb(manualInput.trim());
    };

    const verifyHerb = async (batchId) => {
      try {
        const herbData = await getHerbFromDatabase(batchId);
        if (herbData) {
          onNavigate('herb-details', herbData);
        } else {
          alert('Herb not found. Please check the batch ID.');
        }
      } catch (error) {
        alert('Error verifying herb. Please try again.');
      }
    };

    React.useEffect(() => {
      return () => {
        stopScanning();
      };
    }, []);

    return (
      <div className="min-h-screen bg-gray-50" data-name="qr-scanner" data-file="components/QRScanner.js">
        <Header title="Scan QR Code" onBack={onBack} />
        
        <div className="p-6 space-y-6">
          {!scanning ? (
            <div className="card text-center space-y-6">
              <div className="w-20 h-20 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto">
                <div className="icon-qr-code text-3xl text-[var(--primary-color)]"></div>
              </div>
              
              <div>
                <h2 className="text-xl font-bold text-[var(--text-primary)] mb-2">
                  Verify Your Herbs
                </h2>
                <p className="text-[var(--text-secondary)]">
                  Scan the QR code on your herb package or enter the batch ID manually
                </p>
              </div>

              <button
                onClick={startScanning}
                className="w-full btn-primary flex items-center justify-center space-x-3"
              >
                <div className="icon-camera text-xl"></div>
                <span>Start Camera Scan</span>
              </button>
            </div>
          ) : (
            <div className="card text-center space-y-4">
              <h3 className="text-lg font-semibold text-[var(--text-primary)]">
                Point camera at QR code
              </h3>
              <div className="relative bg-black rounded-lg overflow-hidden">
                <video ref={videoRef} className="w-full h-64 object-cover"></video>
                <div className="absolute inset-0 border-4 border-[var(--primary-color)] border-dashed rounded-lg"></div>
              </div>
              <button
                onClick={stopScanning}
                className="btn-secondary"
              >
                Stop Scanning
              </button>
            </div>
          )}

          <div className="card space-y-4">
            <h3 className="text-lg font-semibold text-[var(--text-primary)] text-center">
              Upload QR Image
            </h3>
            <input
              type="file"
              accept="image/*"
              onChange={async (e) => {
                const file = e.target.files[0];
                if (file) {
                  try {
                    const reader = new FileReader();
                    reader.onload = async (event) => {
                      const imageUrl = event.target.result;
                      
                      // Create image element
                      const img = new Image();
                      img.onload = async () => {
                        try {
                          // Use QR Scanner library to decode from image
                          const result = await QrScanner.scanImage(img);
                          await verifyHerb(result);
                        } catch (error) {
                          alert('Could not detect QR code in the image. Please try with a clearer image or use manual entry.');
                        }
                      };
                      img.src = imageUrl;
                    };
                    reader.readAsDataURL(file);
                  } catch (error) {
                    alert('Error processing image. Please try again.');
                  }
                }
              }}
              className="input-field"
            />
            <p className="text-xs text-[var(--text-secondary)] text-center">
              Upload a clear image of the QR code to verify authenticity
            </p>
          </div>

          <div className="card space-y-4">
            <h3 className="text-lg font-semibold text-[var(--text-primary)] text-center">
              Enter Batch ID Manually
            </h3>
            <div className="flex space-x-3">
              <input
                type="text"
                value={manualInput}
                onChange={(e) => setManualInput(e.target.value)}
                placeholder="Enter batch ID (e.g., HERB001)"
                className="flex-1 input-field"
              />
              <button
                onClick={handleManualVerify}
                className="btn-primary"
              >
                Verify
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('QRScanner component error:', error);
    return null;
  }
}