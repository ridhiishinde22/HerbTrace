function MapView({ location }) {
  try {
    if (!location) {
      return (
        <div className="w-full h-48 bg-gray-200 rounded-lg flex items-center justify-center">
          <p className="text-gray-500">Location not available</p>
        </div>
      );
    }

    const mapUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${location.longitude-0.01},${location.latitude-0.01},${location.longitude+0.01},${location.latitude+0.01}&layer=mapnik&marker=${location.latitude},${location.longitude}`;

    return (
      <div className="space-y-3" data-name="map-view" data-file="components/MapView.js">
        <div className="w-full h-48 rounded-lg overflow-hidden border border-[var(--border-color)]">
          <iframe
            src={mapUrl}
            width="100%"
            height="100%"
            style={{ border: 0 }}
            loading="lazy"
            title="Farm Location Map"
          ></iframe>
        </div>
        
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-2">
            <div className="icon-map-pin text-lg text-[var(--primary-color)]"></div>
            <span className="text-[var(--text-secondary)]">GPS Coordinates</span>
          </div>
          <div className="text-right">
            <p className="font-mono text-[var(--text-primary)]">
              {location.latitude.toFixed(6)}, {location.longitude.toFixed(6)}
            </p>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('MapView component error:', error);
    return (
      <div className="w-full h-48 bg-red-50 rounded-lg flex items-center justify-center">
        <p className="text-red-500">Error loading map</p>
      </div>
    );
  }
}