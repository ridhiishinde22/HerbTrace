function CompliancePage({ onNavigate }) {
  try {
    const [complianceData] = React.useState({
      ayushCompliance: 96,
      exportReadiness: 89,
      traceabilityScore: 99,
      qualityMetrics: {
        purityTests: 98,
        heavyMetals: 100,
        pesticides: 97,
        microbes: 99
      },
      recentReports: [
        { date: '2025-09-20', type: 'AYUSH Audit', status: 'Passed', score: 96 },
        { date: '2025-09-15', type: 'Export Compliance', status: 'Approved', score: 89 },
        { date: '2025-09-10', type: 'Quality Assurance', status: 'Excellent', score: 98 }
      ]
    });

    const handleGenerateReport = (format) => {
      const reportContent = `HERBTRACE COMPLIANCE REPORT
Generated: ${new Date().toLocaleString()}

AYUSH COMPLIANCE SUMMARY:
• Overall Compliance Score: ${complianceData.ayushCompliance}%
• Export Readiness: ${complianceData.exportReadiness}%  
• Traceability Score: ${complianceData.traceabilityScore}%

QUALITY METRICS:
• Purity Tests: ${complianceData.qualityMetrics.purityTests}% Pass Rate
• Heavy Metal Tests: ${complianceData.qualityMetrics.heavyMetals}% Pass Rate
• Pesticide Tests: ${complianceData.qualityMetrics.pesticides}% Pass Rate
• Microbial Tests: ${complianceData.qualityMetrics.microbes}% Pass Rate

RECENT AUDIT RESULTS:
${complianceData.recentReports.map(report => 
  `• ${report.date}: ${report.type} - ${report.status} (Score: ${report.score}%)`
).join('\n')}

AYUSH STANDARDS MET:
• Good Manufacturing Practices (GMP) Guidelines
• Quality Control Standards for Ayurvedic Products
• Labeling and Packaging Requirements
• Traceability and Documentation Standards
• Organic Certification Compliance
• Heavy Metal Limits as per AYUSH Guidelines
• Pesticide Residue Limits Compliance
• Microbial Contamination Standards

EXPORT COMPLIANCE:
• International Organic Standards (NPOP/NOP/JAS)
• Phytosanitary Certificates Available
• Country-specific Export Requirements Met
• Documentation Completeness: 100%
• Chain of Custody Maintained

Report Generated: ${new Date().toLocaleString()}
Compliance Officer: HerbTrace QA Team`;

      if (format === 'json') {
        const jsonData = {
          reportDate: new Date().toISOString(),
          complianceScore: complianceData.ayushCompliance,
          exportReadiness: complianceData.exportReadiness,
          traceabilityScore: complianceData.traceabilityScore,
          qualityMetrics: complianceData.qualityMetrics,
          auditHistory: complianceData.recentReports,
          standards: ['GMP', 'AYUSH', 'Organic', 'Export']
        };
        
        const blob = new Blob([JSON.stringify(jsonData, null, 2)], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `compliance_report_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      } else {
        const element = document.createElement('a');
        const file = new Blob([reportContent], {type: 'text/plain'});
        element.href = URL.createObjectURL(file);
        element.download = `ayush_compliance_report_${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
      }
    };

    return (
      <div className="min-h-screen" data-name="compliance-page" data-file="components/CompliancePage.js">
        <Navigation onNavigate={onNavigate} currentPage="compliance" />
        
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">Compliance Reports</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AYUSH compliance status, export readiness, and quality assurance metrics 
              for regulatory compliance and international trade.
            </p>
          </div>

          {/* Compliance Overview */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="card text-center">
              <div className="text-3xl font-bold text-green-600">{complianceData.ayushCompliance}%</div>
              <div className="text-lg font-semibold text-gray-900">AYUSH Compliance</div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div className="bg-green-600 h-2 rounded-full" style={{width: `${complianceData.ayushCompliance}%`}}></div>
              </div>
            </div>
            <div className="card text-center">
              <div className="text-3xl font-bold text-blue-600">{complianceData.exportReadiness}%</div>
              <div className="text-lg font-semibold text-gray-900">Export Readiness</div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{width: `${complianceData.exportReadiness}%`}}></div>
              </div>
            </div>
            <div className="card text-center">
              <div className="text-3xl font-bold text-purple-600">{complianceData.traceabilityScore}%</div>
              <div className="text-lg font-semibold text-gray-900">Traceability Score</div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div className="bg-purple-600 h-2 rounded-full" style={{width: `${complianceData.traceabilityScore}%`}}></div>
              </div>
            </div>
          </div>

          {/* Quality Metrics */}
          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-6">Quality Test Results</h2>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="p-4 bg-green-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-green-600">{complianceData.qualityMetrics.purityTests}%</div>
                <div className="text-sm text-green-800">Purity Tests</div>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-blue-600">{complianceData.qualityMetrics.heavyMetals}%</div>
                <div className="text-sm text-blue-800">Heavy Metal Tests</div>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-purple-600">{complianceData.qualityMetrics.pesticides}%</div>
                <div className="text-sm text-purple-800">Pesticide Tests</div>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-orange-600">{complianceData.qualityMetrics.microbes}%</div>
                <div className="text-sm text-orange-800">Microbial Tests</div>
              </div>
            </div>
          </div>

          {/* Generate Reports */}
          <div className="card">
            <h2 className="text-2xl font-bold mb-6">Generate Compliance Reports</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Report Options</h3>
                <div className="space-y-3">
                  <button 
                    onClick={() => handleGenerateReport('pdf')} 
                    className="w-full btn-primary flex items-center justify-center space-x-2"
                  >
                    <div className="icon-file-text text-lg"></div>
                    <span>Generate AYUSH Report (PDF)</span>
                  </button>
                  <button 
                    onClick={() => handleGenerateReport('json')} 
                    className="w-full btn-secondary flex items-center justify-center space-x-2"
                  >
                    <div className="icon-download text-lg"></div>
                    <span>Export Data (JSON)</span>
                  </button>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4">Recent Audit History</h3>
                <div className="space-y-2">
                  {complianceData.recentReports.map((report, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium">{report.type}</div>
                        <div className="text-sm text-gray-600">{report.date}</div>
                      </div>
                      <div className="text-right">
                        <div className={`px-2 py-1 rounded-full text-xs ${
                          report.status === 'Passed' || report.status === 'Approved' || report.status === 'Excellent' 
                          ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {report.status}
                        </div>
                        <div className="text-sm font-medium">{report.score}%</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('CompliancePage component error:', error);
    return null;
  }
}