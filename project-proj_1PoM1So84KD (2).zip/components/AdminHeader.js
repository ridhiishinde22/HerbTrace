function AdminHeader({ title }) {
  return (
    <div className="bg-white shadow-md border-b">
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => window.location.href = 'index.html'}
            className="flex items-center space-x-2 hover:bg-gray-100 px-3 py-2 rounded-lg transition-colors"
          >
            <div className="icon-arrow-left text-lg text-gray-600"></div>
            <span className="text-gray-600">Back to Dashboard</span>
          </button>
          <div className="h-6 border-l border-gray-300"></div>
          <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
            <div className="icon-leaf text-lg text-white"></div>
          </div>
          <span className="text-lg font-semibold text-gray-900">HerbTrace Admin</span>
        </div>
      </div>
    </div>
  );
}