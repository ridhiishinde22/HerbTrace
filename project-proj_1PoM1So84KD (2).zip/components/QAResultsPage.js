function QAResultsPage({ onNavigate }) {
  try {
    const [faqs] = React.useState([
      {
        question: "What does Organic Certified mean?",
        answer: "Certified by authorized bodies as free of chemical pesticides, synthetic fertilizers, and GMOs. Our organic herbs meet NPOP (National Program for Organic Production) standards."
      },
      {
        question: "How accurate is the blockchain verification?",
        answer: "Our blockchain system provides 99.99% accuracy with tamper-proof records. Each batch gets a unique cryptographic hash that cannot be altered or duplicated."
      },
      {
        question: "What quality tests are performed on herbs?",
        answer: "We conduct comprehensive testing including purity analysis, heavy metal detection, pesticide residue testing, microbial contamination checks, and authenticity verification."
      },
      {
        question: "How to verify if a herb is genuine?",
        answer: "Scan the QR code on packaging or enter the batch ID manually. You'll see complete farm details, quality test results, and blockchain verification status."
      },
      {
        question: "What is the shelf life of traced herbs?",
        answer: "Varies by herb type and processing method. Dried herbs typically last 1-3 years when stored properly. Check the harvest date and processing details in verification results."
      },
      {
        question: "Are all farmers on the platform certified?",
        answer: "We verify farmer credentials and farm locations. While not all farmers may have formal organic certification, we track their farming practices and quality standards."
      }
    ]);

    const [selectedFaq, setSelectedFaq] = React.useState(null);

    return (
      <div className="min-h-screen" data-name="qa-results-page" data-file="components/QAResultsPage.js">
        <Navigation onNavigate={onNavigate} currentPage="qa-results" />
        
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">Quality Assurance Results</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Frequently asked questions about our quality standards, testing procedures, 
              and verification processes.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="card text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="icon-check-circle text-2xl text-green-600"></div>
              </div>
              <h3 className="text-xl font-semibold mb-2">99.8% Pass Rate</h3>
              <p className="text-gray-600">Quality tests consistently meet standards</p>
            </div>
            <div className="card text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="icon-shield-check text-2xl text-blue-600"></div>
              </div>
              <h3 className="text-xl font-semibold mb-2">Certified Labs</h3>
              <p className="text-gray-600">NABL accredited testing facilities</p>
            </div>
            <div className="card text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="icon-award text-2xl text-purple-600"></div>
              </div>
              <h3 className="text-xl font-semibold mb-2">AYUSH Compliant</h3>
              <p className="text-gray-600">Meets Ministry of AYUSH standards</p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">Frequently Asked Questions</h2>
            </div>
            <div className="divide-y divide-gray-200">
              {faqs.map((faq, index) => (
                <div key={index} className="p-6">
                  <button
                    onClick={() => setSelectedFaq(selectedFaq === index ? null : index)}
                    className="w-full flex justify-between items-center text-left"
                  >
                    <h3 className="text-lg font-semibold text-gray-900 pr-4">{faq.question}</h3>
                    <div className={`icon-${selectedFaq === index ? 'chevron-up' : 'chevron-down'} text-lg text-gray-500 flex-shrink-0`}></div>
                  </button>
                  {selectedFaq === index && (
                    <div className="mt-4 text-gray-600 leading-relaxed">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('QAResultsPage component error:', error);
    return null;
  }
}