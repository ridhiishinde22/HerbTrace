function FarmerForm({ currentUser, onNavigate, onBack }) {
  try {
    const [formData, setFormData] = React.useState({
      herbName: '',
      quantity: '',
      location: null,
      photo: null,
      processing: [],
      testing: [],
      organicCertified: false,
      qualityGrade: 'Standard'
    });
    const [loading, setLoading] = React.useState(false);
    const [locationLoading, setLocationLoading] = React.useState(false);

    const herbOptions = [
      'Ashwagandha', 'Tulsi', 'Neem', 'Giloy', 'Amla', 
      'Brahmi', 'Shatavari', 'Haritaki', 'Arjuna', 'Mulethi'
    ];

    const processingOptions = [
      'Organic Drying', 'Steam Processing', 'Sun Drying', 
      'Machine Processing', 'Traditional Methods'
    ];

    const testingOptions = [
      'Purity Test', 'Heavy Metal Test', 'Pesticide Test',
      'Microbial Test', 'Authenticity Test'
    ];

    const handleLocationCapture = async () => {
      setLocationLoading(true);
      try {
        const location = await getCurrentLocation();
        setFormData(prev => ({ ...prev, location }));
      } catch (error) {
        alert('Error getting location. Please try again.');
      } finally {
        setLocationLoading(false);
      }
    };

    const handleManualLocation = () => {
      onNavigate('location-picker');
    };

    const toggleProcessing = (process) => {
      setFormData(prev => ({
        ...prev,
        processing: prev.processing.includes(process)
          ? prev.processing.filter(p => p !== process)
          : [...prev.processing, process]
      }));
    };

    const toggleTesting = (test) => {
      setFormData(prev => ({
        ...prev,
        testing: prev.testing.includes(test)
          ? prev.testing.filter(t => t !== test)
          : [...prev.testing, test]
      }));
    };

    const handlePhotoUpload = (event) => {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setFormData(prev => ({ ...prev, photo: e.target.result }));
        };
        reader.readAsDataURL(file);
      }
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      
      console.log('=== Form Submission Started ===');
      console.log('Form data:', formData);
      
      if (!formData.herbName || !formData.quantity || !formData.location) {
        alert('Please fill all required fields and capture location');
        return;
      }

      setLoading(true);
      try {
        console.log('Form validation passed. Calling addHerbToDatabase...');
        const batchId = await addHerbToDatabase(formData, currentUser?.userId, currentUser?.fullName);
        console.log('Successfully created herb with batch ID:', batchId);
        onNavigate('qr-generated', { batchId });
      } catch (error) {
        console.error('=== Form Submission Error ===');
        console.error('Error details:', error);
        
        let errorMessage = 'Unknown error occurred';
        if (error.message) {
          errorMessage = error.message;
        }
        
        // Show user-friendly error message
        alert(`Failed to save herb data. Please try again.\n\nTechnical details: ${errorMessage}`);
      } finally {
        setLoading(false);
      }
    };

    return (
      <div className="min-h-screen bg-gray-50" data-name="farmer-form" data-file="components/FarmerForm.js">
        <Header title="Add Herb Collection" onBack={onBack} />
        
        <div className="p-6">
          <form onSubmit={handleSubmit} className="card space-y-6">
            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Herb Name *
              </label>
              <select
                value={formData.herbName}
                onChange={(e) => setFormData(prev => ({ ...prev, herbName: e.target.value }))}
                className="input-field"
                required
              >
                <option value="">Select herb</option>
                {herbOptions.map(herb => (
                  <option key={herb} value={herb}>{herb}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Quantity (kg) *
              </label>
              <input
                type="number"
                value={formData.quantity}
                onChange={(e) => setFormData(prev => ({ ...prev, quantity: e.target.value }))}
                className="input-field"
                placeholder="Enter quantity"
                min="0.1"
                step="0.1"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                GPS Location *
              </label>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={handleLocationCapture}
                  disabled={locationLoading}
                  className="btn-secondary flex items-center space-x-2 text-sm"
                >
                  {locationLoading ? (
                    <div className="icon-loader-2 text-lg animate-spin"></div>
                  ) : (
                    <div className="icon-map-pin text-lg"></div>
                  )}
                  <span>{locationLoading ? 'Getting...' : 'Current GPS'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleManualLocation}
                  className="btn-secondary flex items-center space-x-2 text-sm"
                >
                  <div className="icon-map text-lg"></div>
                  <span>Manual Entry</span>
                </button>
                {formData.location && (
                  <span className="text-sm text-[var(--primary-color)] font-medium">✓ Located</span>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Processing Methods
              </label>
              <div className="grid grid-cols-2 gap-2">
                {processingOptions.map(process => (
                  <label key={process} className="flex items-center space-x-2 text-sm">
                    <input
                      type="checkbox"
                      checked={formData.processing.includes(process)}
                      onChange={() => toggleProcessing(process)}
                      className="rounded border-gray-300"
                    />
                    <span>{process}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Quality Tests
              </label>
              <div className="grid grid-cols-2 gap-2">
                {testingOptions.map(test => (
                  <label key={test} className="flex items-center space-x-2 text-sm">
                    <input
                      type="checkbox"
                      checked={formData.testing.includes(test)}
                      onChange={() => toggleTesting(test)}
                      className="rounded border-gray-300"
                    />
                    <span>{test}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                  Quality Grade
                </label>
                <select
                  value={formData.qualityGrade}
                  onChange={(e) => setFormData(prev => ({ ...prev, qualityGrade: e.target.value }))}
                  className="input-field"
                >
                  <option value="Premium">Premium</option>
                  <option value="Standard">Standard</option>
                  <option value="Basic">Basic</option>
                </select>
              </div>
              <div className="flex items-end">
                <label className="flex items-center space-x-2 text-sm">
                  <input
                    type="checkbox"
                    checked={formData.organicCertified}
                    onChange={(e) => setFormData(prev => ({ ...prev, organicCertified: e.target.checked }))}
                    className="rounded border-gray-300"
                  />
                  <span>Organic Certified</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Herb Photo
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="input-field"
              />
              {formData.photo && (
                <div className="mt-3">
                  <img src={formData.photo} alt="Herb" className="w-20 h-20 object-cover rounded-lg" />
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary flex items-center justify-center space-x-2"
            >
              {loading ? (
                <>
                  <div className="icon-loader-2 text-lg animate-spin"></div>
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <div className="icon-check text-lg"></div>
                  <span>Add to Blockchain</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    );
  } catch (error) {
    console.error('FarmerForm component error:', error);
    return null;
  }
}