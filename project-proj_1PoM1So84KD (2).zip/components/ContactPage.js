function ContactPage({ onNavigate }) {
  try {
    return (
      <div className="min-h-screen" data-name="contact-page" data-file="components/ContactPage.js">
        <Navigation onNavigate={onNavigate} currentPage="contact" />
        
        <div className="max-w-7xl mx-auto px-4 py-16">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">Get In Touch</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Have questions about our platform? Need support? We're here to help you with 
              herb traceability and verification.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-8">Contact Information</h2>
              
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center">
                    <div className="icon-mail text-xl text-[var(--primary-color)]"></div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Email Us</h3>
                    <p className="text-gray-600">support@herbtrace.com</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center">
                    <div className="icon-phone text-xl text-[var(--primary-color)]"></div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Call Us</h3>
                    <p className="text-gray-600">+91 98765 43210</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center">
                    <div className="icon-map-pin text-xl text-[var(--primary-color)]"></div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Visit Us</h3>
                    <p className="text-gray-600">123 Herb Street, Green Valley, India</p>
                  </div>
                </div>
              </div>

              {/* Social Media */}
              <div className="mt-12">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Follow Us</h3>
                <div className="flex space-x-4">
                  <a href="https://instagram.com/herbtrace" target="_blank" rel="noopener noreferrer" 
                     className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center hover:bg-pink-200 transition-colors">
                    <div className="icon-instagram text-xl text-pink-600"></div>
                  </a>
                  <a href="https://facebook.com/herbtrace" target="_blank" rel="noopener noreferrer"
                     className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center hover:bg-blue-200 transition-colors">
                    <div className="icon-facebook text-xl text-blue-600"></div>
                  </a>
                  <a href="https://wa.me/919876543210" target="_blank" rel="noopener noreferrer"
                     className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center hover:bg-green-200 transition-colors">
                    <div className="icon-message-circle text-xl text-green-600"></div>
                  </a>
                  <a href="https://twitter.com/herbtrace" target="_blank" rel="noopener noreferrer"
                     className="w-12 h-12 bg-sky-100 rounded-lg flex items-center justify-center hover:bg-sky-200 transition-colors">
                    <div className="icon-twitter text-xl text-sky-600"></div>
                  </a>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Send Message</h2>
                <button
                  onClick={() => {
                    const issueType = prompt('Issue Type:\n1. Technical Problem\n2. Verification Failed\n3. Account Issue\n4. Feature Request\n5. Other\n\nEnter number (1-5):');
                    if (issueType) {
                      const types = ['Technical Problem', 'Verification Failed', 'Account Issue', 'Feature Request', 'Other'];
                      const selectedType = types[parseInt(issueType) - 1] || 'Other';
                      alert(`Issue Report: ${selectedType}\n\nYour issue has been logged with ID: #${Math.floor(Math.random() * 10000)}\n\nOur support team will contact you within 24 hours.`);
                    }
                  }}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-red-700 transition-colors"
                >
                  Report Issue
                </button>
              </div>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                  <input type="text" className="input-field" placeholder="Your Name" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input type="email" className="input-field" placeholder="your@email.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Message Type</label>
                  <select className="input-field">
                    <option>General Inquiry</option>
                    <option>Technical Support</option>
                    <option>Feature Request</option>
                    <option>Partnership Inquiry</option>
                    <option>Feedback</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                  <input type="text" className="input-field" placeholder="Subject" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                  <textarea rows="4" className="input-field" placeholder="Your message here..."></textarea>
                </div>
                <div className="flex space-x-3">
                  <button type="submit" className="btn-primary flex-1">Send Message</button>
                  <button 
                    type="button"
                    onClick={() => window.open('https://wa.me/919876543210', '_blank')}
                    className="btn-secondary flex items-center space-x-2"
                  >
                    <div className="icon-message-circle text-lg"></div>
                    <span>WhatsApp</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ContactPage component error:', error);
    return null;
  }
}
