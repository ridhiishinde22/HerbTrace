function FarmerDashboard({ currentUser, onNavigate, onLogout }) {
  try {
    const [collections, setCollections] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [stats, setStats] = React.useState({
      totalCollections: 0,
      totalQuantity: 0,
      verifiedCount: 0
    });

    React.useEffect(() => {
      loadFarmerCollections();
    }, []);

    const loadFarmerCollections = async () => {
      try {
        const farmerCollections = await getFarmerCollections(currentUser?.userId);
        setCollections(farmerCollections);
        
        const totalQuantity = farmerCollections.reduce((sum, item) => sum + parseFloat(item.quantity || 0), 0);
        setStats({
          totalCollections: farmerCollections.length,
          totalQuantity: totalQuantity.toFixed(1),
          verifiedCount: farmerCollections.length
        });
      } catch (error) {
        console.error('Error loading collections:', error);
      } finally {
        setLoading(false);
      }
    };

    const copyBatchId = (batchId) => {
      navigator.clipboard.writeText(batchId).then(() => {
        alert(`Batch ID copied: ${batchId}`);
      }).catch(() => {
        alert(`Batch ID: ${batchId}`);
      });
    };

    return (
      <div className="min-h-screen bg-gray-50" data-name="farmer-dashboard" data-file="components/FarmerDashboard.js">
        <div className="mobile-header">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
              <div className="icon-sprout text-sm text-white"></div>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-[var(--text-primary)]">Farmer Portal</h1>
              <p className="text-xs text-[var(--text-secondary)]">Welcome, {currentUser?.fullName}</p>
            </div>
          </div>
          <button onClick={onLogout} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <div className="icon-log-out text-xl text-[var(--text-primary)]"></div>
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Stats Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white rounded-lg p-3 text-center shadow-sm">
              <div className="text-lg font-bold text-[var(--primary-color)]">{stats.totalCollections}</div>
              <div className="text-xs text-[var(--text-secondary)]">Collections</div>
            </div>
            <div className="bg-white rounded-lg p-3 text-center shadow-sm">
              <div className="text-lg font-bold text-[var(--primary-color)]">{stats.totalQuantity}kg</div>
              <div className="text-xs text-[var(--text-secondary)]">Total Harvest</div>
            </div>
            <div className="bg-white rounded-lg p-3 text-center shadow-sm">
              <div className="text-lg font-bold text-[var(--primary-color)]">{stats.verifiedCount}</div>
              <div className="text-xs text-[var(--text-secondary)]">Verified</div>
            </div>
          </div>

          {/* Add Collection Button */}
          <button
            onClick={() => onNavigate('farmer-form')}
            className="w-full btn-primary flex items-center justify-center space-x-2"
          >
            <div className="icon-plus text-lg"></div>
            <span>Add New Collection</span>
          </button>

          {/* Collections List */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-[var(--text-primary)]">My Collections</h3>
              <button
                onClick={loadFarmerCollections}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="icon-refresh-cw text-lg text-[var(--primary-color)]"></div>
              </button>
            </div>
            
            {loading ? (
              <div className="text-center py-8">
                <div className="icon-loader-2 text-2xl text-[var(--primary-color)] animate-spin"></div>
                <p className="text-[var(--text-secondary)] mt-2">Loading collections...</p>
              </div>
            ) : collections.length === 0 ? (
              <div className="card text-center py-8">
                <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="icon-package text-2xl text-[var(--primary-color)]"></div>
                </div>
                <h4 className="font-semibold text-[var(--text-primary)] mb-2">No Collections Yet</h4>
                <p className="text-sm text-[var(--text-secondary)] mb-4">Start by adding your first herb collection to the blockchain</p>
                <button
                  onClick={() => onNavigate('farmer-form')}
                  className="btn-primary text-sm"
                >
                  Add First Collection
                </button>
              </div>
            ) : (
              collections.map(collection => (
                <div key={collection.batchId} className="bg-white rounded-lg p-4 shadow-sm border hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-[var(--secondary-color)] rounded-lg flex items-center justify-center">
                        <div className="icon-leaf text-lg text-[var(--primary-color)]"></div>
                      </div>
                      <div>
                        <h4 className="font-semibold text-[var(--text-primary)]">{collection.herbName}</h4>
                        <p className="text-sm text-[var(--text-secondary)]">{collection.quantity} kg • Grade: {collection.qualityGrade}</p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-1">
                      <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                        ✓ Blockchain Verified
                      </span>
                      {collection.organicCertified && (
                        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                          🌱 Organic
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mb-3">
                    {collection.processing && collection.processing.slice(0, 2).map((method, index) => (
                      <span key={index} className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded">
                        {method}
                      </span>
                    ))}
                    {collection.testing && collection.testing.slice(0, 2).map((test, index) => (
                      <span key={index} className="text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded">
                        {test}
                      </span>
                    ))}
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-[var(--text-secondary)]">
                      Harvested: {collection.harvestDate}
                    </span>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => onNavigate('qr-generated', { batchId: collection.batchId })}
                        className="text-xs bg-blue-600 text-white px-3 py-1 rounded-lg flex items-center space-x-1"
                      >
                        <div className="icon-qr-code text-xs"></div>
                        <span>QR</span>
                      </button>
                      <button
                        onClick={() => copyBatchId(collection.batchId)}
                        className="text-xs bg-[var(--primary-color)] text-white px-3 py-1 rounded-lg flex items-center space-x-1"
                      >
                        <div className="icon-copy text-xs"></div>
                        <span>Copy ID</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('FarmerDashboard component error:', error);
    return null;
  }
}