function StakeholdersPage({ onNavigate }) {
  try {
    const [networkData] = React.useState({
      totalFarms: 124,
      activeBatches: 1247,
      qaPassRate: 99.8,
      issuesFlagged: 3,
      harvestVolumes: [
        { crop: 'Ashwagandha', volume: 2400, region: 'Punjab' },
        { crop: 'Tulsi', volume: 1800, region: 'Maharashtra' },
        { crop: 'Neem', volume: 1500, region: 'Gujarat' },
        { crop: 'Giloy', volume: 1200, region: 'Rajasthan' }
      ],
      compliance: {
        ayushCompliant: 96,
        recentAudits: 'Passed - Sept 2025',
        certificationRate: 68
      }
    });

    return (
      <div className="min-h-screen" data-name="stakeholders-page" data-file="components/StakeholdersPage.js">
        <Navigation onNavigate={onNavigate} currentPage="stakeholders" />
        
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">Stakeholder Network</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Real-time insights into our network health, harvest volumes, and compliance metrics 
              for all stakeholders in the herb traceability ecosystem.
            </p>
          </div>

          {/* Network Health Panel */}
          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <div className="icon-activity text-2xl text-[var(--primary-color)] mr-3"></div>
              Network Health Panel
            </h2>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-3xl font-bold text-green-600">{networkData.totalFarms}</div>
                <div className="text-sm text-green-800">Total Farms</div>
                <div className="w-2 h-2 bg-green-500 rounded-full mx-auto mt-2"></div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-3xl font-bold text-blue-600">{networkData.activeBatches}</div>
                <div className="text-sm text-blue-800">Active Batches</div>
                <div className="w-2 h-2 bg-blue-500 rounded-full mx-auto mt-2"></div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-3xl font-bold text-purple-600">{networkData.qaPassRate}%</div>
                <div className="text-sm text-purple-800">QA Pass Rate</div>
                <div className="w-2 h-2 bg-purple-500 rounded-full mx-auto mt-2"></div>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <div className="text-3xl font-bold text-orange-600">{networkData.issuesFlagged}</div>
                <div className="text-sm text-orange-800">Issues Flagged</div>
                <div className="w-2 h-2 bg-orange-500 rounded-full mx-auto mt-2"></div>
              </div>
            </div>
          </div>

          {/* Harvest Volumes Tracker */}
          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <div className="icon-bar-chart text-2xl text-[var(--primary-color)] mr-3"></div>
              Harvest Volumes Tracker
            </h2>
            <div className="space-y-4">
              {networkData.harvestVolumes.map((item, index) => (
                <div key={index} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <div>
                    <h3 className="font-semibold text-gray-900">{item.crop}</h3>
                    <p className="text-sm text-gray-600">{item.region}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-[var(--primary-color)]">{item.volume} kg</div>
                    <div className="w-32 bg-gray-200 rounded-full h-2 mt-1">
                      <div 
                        className="bg-[var(--primary-color)] h-2 rounded-full" 
                        style={{width: `${(item.volume / 2400) * 100}%`}}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Compliance Summary */}
          <div className="card">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <div className="icon-shield-check text-2xl text-[var(--primary-color)] mr-3"></div>
              Compliance Summary
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-6 bg-green-50 rounded-lg">
                <div className="text-3xl font-bold text-green-600">{networkData.compliance.ayushCompliant}%</div>
                <div className="text-sm text-green-800 font-medium">AYUSH Standards</div>
                <div className="text-xs text-green-600 mt-2">Fully Compliant</div>
              </div>
              <div className="text-center p-6 bg-blue-50 rounded-lg">
                <div className="text-lg font-bold text-blue-600">{networkData.compliance.recentAudits}</div>
                <div className="text-sm text-blue-800 font-medium">Recent Audit</div>
                <div className="text-xs text-blue-600 mt-2">All Standards Met</div>
              </div>
              <div className="text-center p-6 bg-purple-50 rounded-lg">
                <div className="text-3xl font-bold text-purple-600">{networkData.compliance.certificationRate}%</div>
                <div className="text-sm text-purple-800 font-medium">Certification Rate</div>
                <div className="text-xs text-purple-600 mt-2">Organic Certified</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('StakeholdersPage component error:', error);
    return null;
  }
}