function HomePage({ onNavigate }) {
  try {
    return (
      <div className="min-h-screen" data-name="home-page" data-file="components/HomePage.js">
        <Navigation onNavigate={onNavigate} currentPage="home" />
        
        {/* Hero Section */}
        <div className="relative bg-gradient-to-br from-green-50 to-green-100 py-20">
          <div className="absolute inset-0 bg-black bg-opacity-5"></div>
          <div className="relative max-w-7xl mx-auto px-4 text-center">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-8 shadow-lg">
              <div className="icon-leaf text-3xl text-[var(--primary-color)]"></div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Ayurvedic Herb <span className="text-gradient">Traceability</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Track your Ayurvedic herbs from farm to consumer with blockchain verification. 
              Ensuring authenticity, quality, and trust in every herb you consume.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('login-farmer')}
                className="btn-primary text-lg px-8 py-4"
              >
                <div className="icon-users text-xl mr-2"></div>
                Farmer Portal
              </button>
              <button
                onClick={() => onNavigate('login-customer')}
                className="btn-secondary text-lg px-8 py-4"
              >
                <div className="icon-search text-xl mr-2"></div>
                Verify Herbs
              </button>
            </div>
          </div>
        </div>

        {/* Features Preview */}
        <div className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Why Choose Our Platform?</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="icon-shield-check text-2xl text-[var(--primary-color)]"></div>
                </div>
                <h3 className="text-xl font-semibold mb-3">Blockchain Verified</h3>
                <p className="text-gray-600">Every herb is tracked on blockchain ensuring complete authenticity and transparency.</p>
              </div>
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="icon-map-pin text-2xl text-[var(--primary-color)]"></div>
                </div>
                <h3 className="text-xl font-semibold mb-3">Farm to Table</h3>
                <p className="text-gray-600">Track the complete journey from farm location to your doorstep.</p>
              </div>
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="icon-qr-code text-2xl text-[var(--primary-color)]"></div>
                </div>
                <h3 className="text-xl font-semibold mb-3">Easy Verification</h3>
                <p className="text-gray-600">Simply scan QR code or enter batch ID to verify herb authenticity instantly.</p>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-[var(--primary-color)] py-16">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Ready to Get Started?</h2>
            <p className="text-xl text-green-100 mb-8">Join thousands of farmers and customers already using our platform.</p>
            <button
              onClick={() => onNavigate('login-admin')}
              className="bg-white text-[var(--primary-color)] px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors"
            >
              Admin Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('HomePage component error:', error);
    return null;
  }
}