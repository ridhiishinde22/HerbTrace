function DataExportPage() {
  const [exportData, setExportData] = React.useState({
    lastBackup: '2025-09-22 06:00:00',
    totalRecords: 2847,
    databaseSize: '2.4 GB',
    exportHistory: [
      { date: '2025-09-22', type: 'Full Export', size: '2.4 GB', status: 'Completed' },
      { date: '2025-09-21', type: 'Incremental', size: '156 MB', status: 'Completed' },
      { date: '2025-09-20', type: 'User Data', size: '45 MB', status: 'Completed' }
    ],
    systemMetrics: {
      herbRecords: 1247,
      userRecords: 980,
      verificationRecords: 3456,
      blockchainTransactions: 2847,
      uploadedImages: 892
    }
  });

  const handleFullExport = (format) => {
    const exportContent = `HERBTRACE FULL DATA EXPORT
Generated: ${new Date().toLocaleString()}

DATABASE SUMMARY:
• Total Records: ${exportData.totalRecords}
• Database Size: ${exportData.databaseSize}
• Last Backup: ${exportData.lastBackup}
• Export Format: ${format.toUpperCase()}

RECORD BREAKDOWN:
• Herb Records: ${exportData.systemMetrics.herbRecords}
• User Records: ${exportData.systemMetrics.userRecords}
• Verification Records: ${exportData.systemMetrics.verificationRecords}
• Blockchain Transactions: ${exportData.systemMetrics.blockchainTransactions}
• Uploaded Images: ${exportData.systemMetrics.uploadedImages}

SYSTEM HEALTH:
• Database Status: Healthy
• Backup Status: Up to date
• Data Integrity: 99.99%
• Export Completion: 100%

EXPORT DETAILS:
• Export Date: ${new Date().toISOString()}
• Export Type: Full Database Export
• Compression: Enabled
• Encryption: AES-256
• File Format: ${format.toUpperCase()}

Note: This is a comprehensive export of all HerbTrace platform data.`;

    const blob = new Blob([exportContent], {type: 'text/plain'});
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `herbtrace_full_export_${new Date().toISOString().split('T')[0]}.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleSelectiveExport = (dataType, format) => {
    let content = '';
    
    switch(dataType) {
      case 'users':
        content = `USER DATA EXPORT
Generated: ${new Date().toLocaleString()}

TOTAL USERS: ${exportData.systemMetrics.userRecords}

FARMER DATA:
• Active Farmers: 124
• Verified Farms: 118
• Organic Certified: 85
• Total Herb Batches: ${exportData.systemMetrics.herbRecords}

CUSTOMER DATA:
• Active Customers: 856
• Total Verifications: ${exportData.systemMetrics.verificationRecords}
• Repeat Customers: 612
• Mobile App Users: 728`;
        break;
      case 'herbs':
        content = `HERB DATA EXPORT
Generated: ${new Date().toLocaleString()}

TOTAL HERB RECORDS: ${exportData.systemMetrics.herbRecords}

TOP HERBS:
• Ashwagandha: 22%
• Tulsi: 18%
• Neem: 15%
• Giloy: 12%
• Amla: 10%

QUALITY METRICS:
• Premium Grade: 25%
• Standard Grade: 65%
• Basic Grade: 10%
• Organic Certified: 68%`;
        break;
      case 'verifications':
        content = `VERIFICATION DATA EXPORT
Generated: ${new Date().toLocaleString()}

TOTAL VERIFICATIONS: ${exportData.systemMetrics.verificationRecords}

VERIFICATION STATS:
• Success Rate: 99.8%
• Average Response Time: 1.2s
• QR Code Scans: 2847
• Manual Verifications: 609
• Failed Verifications: 7`;
        break;
    }

    const blob = new Blob([content], {type: 'text/plain'});
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `herbtrace_${dataType}_export_${new Date().toISOString().split('T')[0]}.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader title="Data Export & Backup" />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* System Overview */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <div className="card text-center">
            <div className="text-2xl font-bold text-blue-600">{exportData.totalRecords}</div>
            <div className="text-sm text-gray-600">Total Records</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-green-600">{exportData.databaseSize}</div>
            <div className="text-sm text-gray-600">Database Size</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-purple-600">99.9%</div>
            <div className="text-sm text-gray-600">Uptime</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-orange-600">AES-256</div>
            <div className="text-sm text-gray-600">Encryption</div>
          </div>
        </div>

        {/* Export Options */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">Full Database Export</h3>
            <p className="text-gray-600 mb-4">Export complete database including all records, user data, and system metrics.</p>
            <div className="space-y-3">
              <button onClick={() => handleFullExport('csv')} className="w-full btn-primary">
                Export as CSV
              </button>
              <button onClick={() => handleFullExport('txt')} className="w-full btn-secondary">
                Export as TXT Report
              </button>
            </div>
          </div>
          
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">Selective Data Export</h3>
            <p className="text-gray-600 mb-4">Export specific data categories based on your requirements.</p>
            <div className="space-y-2">
              <div className="flex space-x-2">
                <button onClick={() => handleSelectiveExport('users', 'csv')} className="flex-1 btn-secondary text-sm">
                  User Data CSV
                </button>
                <button onClick={() => handleSelectiveExport('users', 'txt')} className="flex-1 btn-secondary text-sm">
                  User Report
                </button>
              </div>
              <div className="flex space-x-2">
                <button onClick={() => handleSelectiveExport('herbs', 'csv')} className="flex-1 btn-secondary text-sm">
                  Herb Data CSV
                </button>
                <button onClick={() => handleSelectiveExport('herbs', 'txt')} className="flex-1 btn-secondary text-sm">
                  Herb Report
                </button>
              </div>
              <div className="flex space-x-2">
                <button onClick={() => handleSelectiveExport('verifications', 'csv')} className="flex-1 btn-secondary text-sm">
                  Verification CSV
                </button>
                <button onClick={() => handleSelectiveExport('verifications', 'txt')} className="flex-1 btn-secondary text-sm">
                  Verification Report
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Data Breakdown */}
        <div className="card mb-8">
          <h3 className="text-lg font-semibold mb-4">Data Breakdown</h3>
          <div className="grid md:grid-cols-5 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-xl font-bold text-blue-600">{exportData.systemMetrics.herbRecords}</div>
              <div className="text-sm text-blue-800">Herb Records</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-xl font-bold text-green-600">{exportData.systemMetrics.userRecords}</div>
              <div className="text-sm text-green-800">User Records</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-xl font-bold text-purple-600">{exportData.systemMetrics.verificationRecords}</div>
              <div className="text-sm text-purple-800">Verifications</div>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-xl font-bold text-yellow-600">{exportData.systemMetrics.blockchainTransactions}</div>
              <div className="text-sm text-yellow-800">Blockchain TXs</div>
            </div>
            <div className="text-center p-4 bg-pink-50 rounded-lg">
              <div className="text-xl font-bold text-pink-600">{exportData.systemMetrics.uploadedImages}</div>
              <div className="text-sm text-pink-800">Images</div>
            </div>
          </div>
        </div>

        {/* Export History */}
        <div className="card">
          <h3 className="text-lg font-semibold mb-4">Recent Export History</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Date</th>
                  <th className="text-left py-2">Export Type</th>
                  <th className="text-left py-2">Size</th>
                  <th className="text-left py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {exportData.exportHistory.map((export_, index) => (
                  <tr key={index} className="border-b">
                    <td className="py-2">{export_.date}</td>
                    <td className="py-2">{export_.type}</td>
                    <td className="py-2">{export_.size}</td>
                    <td className="py-2">
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                        {export_.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<DataExportPage />);