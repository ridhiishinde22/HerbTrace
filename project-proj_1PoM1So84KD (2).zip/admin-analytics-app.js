function AnalyticsPage() {
  const [analytics, setAnalytics] = React.useState({
    systemHealth: 99.9,
    userSatisfaction: 4.8,
    totalHerbs: 1247,
    totalUsers: 980,
    verificationSuccess: 99.8,
    averageResponse: 1.2,
    dailyApiCalls: 15847,
    dataStorage: 2.4,
    activeFarmers: 124,
    activeCustomers: 856,
    dailyActiveUsers: 234,
    weeklyRetention: 78,
    monthlyGrowth: 15,
    organicCertified: 68,
    premiumGrade: 25,
    standardGrade: 65,
    basicGrade: 10,
    herbDistribution: [
      { name: 'Ashwagandha', percentage: 22 },
      { name: 'Tulsi', percentage: 18 },
      { name: 'Neem', percentage: 15 },
      { name: 'Giloy', percentage: 12 },
      { name: 'Amla', percentage: 10 }
    ]
  });

  const handleDownloadReport = (format) => {
    const detailedReport = `HERBTRACE COMPREHENSIVE ANALYTICS REPORT
Generated: ${new Date().toLocaleString()}

EXECUTIVE SUMMARY:
• Platform Status: Fully Operational
• Total System Health: ${analytics.systemHealth}% Uptime
• User Satisfaction: ${analytics.userSatisfaction}/5.0 Rating
• Security Status: All Systems Secure

SYSTEM OVERVIEW:
• Total Herbs Tracked: ${analytics.totalHerbs}
• Total Users: ${analytics.totalUsers}
• Verification Success Rate: ${analytics.verificationSuccess}%
• Average Response Time: ${analytics.averageResponse} seconds
• Daily API Calls: ${analytics.dailyApiCalls}
• Data Storage: ${analytics.dataStorage} GB

USER STATISTICS:
• Active Farmers: ${analytics.activeFarmers}
• Active Customers: ${analytics.activeCustomers}
• Daily Active Users: ${analytics.dailyActiveUsers}
• Weekly Retention: ${analytics.weeklyRetention}%
• Monthly Growth Rate: +${analytics.monthlyGrowth}%
• Geographic Reach: 25 States
• Top User Regions: Punjab (35%), Maharashtra (22%), Gujarat (15%)

HERB & QUALITY METRICS:
• Total Batches: ${analytics.totalHerbs}
• Organic Certified: ${analytics.organicCertified}%
• Quality Distribution: Premium (${analytics.premiumGrade}%), Standard (${analytics.standardGrade}%), Basic (${analytics.basicGrade}%)
• Top Herbs: ${analytics.herbDistribution.map(h => `${h.name} (${h.percentage}%)`).join(', ')}
• Average Batch Size: 45 kg
• Processing Methods: Organic Drying (45%), Steam Processing (30%)

BLOCKCHAIN & SECURITY:
• Blocks Generated: 1,247
• Transaction Volume: 2,456
• Hash Accuracy: 99.99%
• Security Incidents: 0
• Data Breaches: 0
• Encryption Status: AES-256 Active

FINANCIAL & BUSINESS:
• Revenue Growth: +28% YoY
• Cost Per Verification: ₹2.50
• Farmer Satisfaction: 95%
• Customer Trust Score: 98%
• ROI for Farmers: +35%

TECHNICAL PERFORMANCE:
• Server Uptime: ${analytics.systemHealth}%
• Database Performance: Excellent
• Network Latency: <100ms
• Error Rate: ${100 - analytics.verificationSuccess}%
• Success Rate: ${analytics.verificationSuccess}%

Report Generated: ${new Date().toLocaleString()}`;

    if (format === 'csv') {
      const csvContent = `data:text/csv;charset=utf-8,Metric,Value
System Health,${analytics.systemHealth}%
User Satisfaction,${analytics.userSatisfaction}/5.0
Total Herbs,${analytics.totalHerbs}
Total Users,${analytics.totalUsers}
Verification Success,${analytics.verificationSuccess}%
Average Response Time,${analytics.averageResponse}s
Daily API Calls,${analytics.dailyApiCalls}
Data Storage,${analytics.dataStorage}GB
Active Farmers,${analytics.activeFarmers}
Active Customers,${analytics.activeCustomers}
Daily Active Users,${analytics.dailyActiveUsers}
Weekly Retention,${analytics.weeklyRetention}%
Monthly Growth,${analytics.monthlyGrowth}%
Organic Certified,${analytics.organicCertified}%`;

      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `analytics_report_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      const element = document.createElement('a');
      const file = new Blob([detailedReport], {type: 'text/plain'});
      element.href = URL.createObjectURL(file);
      element.download = `analytics_comprehensive_report_${new Date().toISOString().split('T')[0]}.txt`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader title="Analytics & Reports" />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Executive Summary */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <div className="card text-center">
            <div className="text-2xl font-bold text-green-600">{analytics.systemHealth}%</div>
            <div className="text-sm text-gray-600">System Health</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-blue-600">{analytics.userSatisfaction}/5.0</div>
            <div className="text-sm text-gray-600">User Satisfaction</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-purple-600">{analytics.verificationSuccess}%</div>
            <div className="text-sm text-gray-600">Success Rate</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-orange-600">{analytics.averageResponse}s</div>
            <div className="text-sm text-gray-600">Response Time</div>
          </div>
        </div>

        {/* System Metrics */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">System Overview</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Total Herbs Tracked</span>
                <span className="font-semibold">{analytics.totalHerbs}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Users</span>
                <span className="font-semibold">{analytics.totalUsers}</span>
              </div>
              <div className="flex justify-between">
                <span>Daily API Calls</span>
                <span className="font-semibold">{analytics.dailyApiCalls}</span>
              </div>
              <div className="flex justify-between">
                <span>Data Storage</span>
                <span className="font-semibold">{analytics.dataStorage} GB</span>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="text-lg font-semibold mb-4">User Analytics</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Active Farmers</span>
                <span className="font-semibold">{analytics.activeFarmers}</span>
              </div>
              <div className="flex justify-between">
                <span>Active Customers</span>
                <span className="font-semibold">{analytics.activeCustomers}</span>
              </div>
              <div className="flex justify-between">
                <span>Daily Active Users</span>
                <span className="font-semibold">{analytics.dailyActiveUsers}</span>
              </div>
              <div className="flex justify-between">
                <span>Monthly Growth</span>
                <span className="font-semibold text-green-600">+{analytics.monthlyGrowth}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Herb Distribution */}
        <div className="card mb-8">
          <h3 className="text-lg font-semibold mb-4">Top Herb Distribution</h3>
          <div className="space-y-3">
            {analytics.herbDistribution.map((herb, index) => (
              <div key={index} className="flex justify-between items-center">
                <span>{herb.name}</span>
                <div className="flex items-center space-x-2">
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div className="bg-[var(--primary-color)] h-2 rounded-full" style={{width: `${herb.percentage}%`}}></div>
                  </div>
                  <span className="text-sm font-semibold">{herb.percentage}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quality Metrics */}
        <div className="card mb-8">
          <h3 className="text-lg font-semibold mb-4">Quality & Certification Metrics</h3>
          <div className="grid md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-xl font-bold text-green-600">{analytics.organicCertified}%</div>
              <div className="text-sm text-green-800">Organic Certified</div>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-xl font-bold text-blue-600">{analytics.premiumGrade}%</div>
              <div className="text-sm text-blue-800">Premium Grade</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-xl font-bold text-purple-600">{analytics.standardGrade}%</div>
              <div className="text-sm text-purple-800">Standard Grade</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="text-xl font-bold text-orange-600">{analytics.basicGrade}%</div>
              <div className="text-sm text-orange-800">Basic Grade</div>
            </div>
          </div>
        </div>

        {/* Download Options */}
        <div className="card">
          <h3 className="text-lg font-semibold mb-4">Download Reports</h3>
          <div className="flex space-x-4">
            <button onClick={() => handleDownloadReport('csv')} className="btn-primary flex items-center space-x-2">
              <div className="icon-download text-lg"></div>
              <span>Download CSV</span>
            </button>
            <button onClick={() => handleDownloadReport('pdf')} className="btn-secondary flex items-center space-x-2">
              <div className="icon-file-text text-lg"></div>
              <span>Download Full Report</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<AnalyticsPage />);